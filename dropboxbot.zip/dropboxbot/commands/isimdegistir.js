const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder().setName('isim-degistir').setDescription('Sistemdeki adınızı günceller.').addStringOption(o => o.setName('yeni_isim').setRequired(true).setDescription('Yeni adınız')),
    async execute(interaction, db) {
        await db.set(`user_${interaction.user.id}.isim`, interaction.options.getString('yeni_isim'));
        await interaction.reply("✅ İsminiz başarıyla güncellendi.");
    }
};
