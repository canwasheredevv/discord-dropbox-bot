const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder().setName('hakkim').setDescription('Kalan yükleme hakkınızı gösterir.'),
    async execute(interaction, db) {
        const hak = await db.get(`user_${interaction.user.id}.hak`);
        if (hak === null) return interaction.reply("Önce hesap açmalısın.");
        await interaction.reply(`🔑 Şu anki yükleme hakkın: **${hak}**`);
    }
};
