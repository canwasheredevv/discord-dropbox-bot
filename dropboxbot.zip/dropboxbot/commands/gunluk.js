const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder().setName('gunluk-hak').setDescription('Günlük yükleme hakkınızı alırsınız.'),
    async execute(interaction, db) {
        const son = await db.get(`user_${interaction.user.id}.sonYenileme`);
        const bugun = new Date().toLocaleDateString();
        if (son === bugun) return interaction.reply("Bugün hakkınızı zaten aldınız!");
        await db.add(`user_${interaction.user.id}.hak`, 1);
        await db.set(`user_${interaction.user.id}.sonYenileme`, bugun);
        await interaction.reply("🎁 Günlük +1 yükleme hakkı eklendi!");
    }
};
