const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-sil')
        .setDescription('Gelen veya giden kutundan bir maili siler.')
        .addStringOption(o =>
            o.setName('id')
             .setDescription('Silinecek mail ID')
             .setRequired(true)
        ),

    async execute(interaction, db) {
        const u = await db.get(`user_${interaction.user.id}`);
        if (!u) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        const id = interaction.options.getString('id');

        u.gelenKutusu = u.gelenKutusu || [];
        u.gidenKutusu = u.gidenKutusu || [];

        const beforeGelen = u.gelenKutusu.length;
        const beforeGiden = u.gidenKutusu.length;

        u.gelenKutusu = u.gelenKutusu.filter(m => m.id !== id);
        u.gidenKutusu = u.gidenKutusu.filter(m => m.id !== id);

        if (u.gelenKutusu.length === beforeGelen && u.gidenKutusu.length === beforeGiden) {
            return interaction.reply({
                content: 'Bu ID ile bir mail bulunamadı.',
                flags: 64
            });
        }

        await db.set(`user_${interaction.user.id}`, u);

        return interaction.reply({
            content: `🗑️ \`${id}\` ID\'li mail kutundan silindi.`,
            flags: 64
        });
    }
};