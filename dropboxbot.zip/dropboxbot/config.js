module.exports = {
    token: "tokenigir",
    sahipID: "sahipidgir",
    botMailUzantisi: "@dropbox.bot",
    embedRenk: "#799dd4",
    varsayilanHak: 30, // kafana gore ayarla
    gunlukHak: 1, // kafana gore ayarla

    logKanalID: "logkanalid",

    // DROPBOX AYARLARI
    dropbox: {
        // Dropbox Developers -> App -> "Generated access token"
        accessToken: "BURAYA_DROPBOX_ACCESS_TOKEN"
    }
};