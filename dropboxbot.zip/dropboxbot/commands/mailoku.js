const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-oku')
        .setDescription('Belirli bir maili detaylı okursun.')
        .addStringOption(o =>
            o.setName('id')
             .setDescription('Mail ID')
             .setRequired(true)
        ),

    async execute(interaction, db) {
        const u = await db.get(`user_${interaction.user.id}`);
        if (!u) {
            return interaction.reply({ content: "Önce `/hesap-olustur` ile kayıt olmalısın!", flags: 64 });
        }

        const id = interaction.options.getString('id');

        u.gelenKutusu = u.gelenKutusu || [];
        u.gidenKutusu = u.gidenKutusu || [];

        let mail = u.gelenKutusu.find(m => m.id === id);
        let tip = 'gelen';

        if (!mail) {
            mail = u.gidenKutusu.find(m => m.id === id);
            tip = 'giden';
        }

        if (!mail) {
            return interaction.reply({ content: 'Bu ID ile bir mail bulunamadı.', flags: 64 });
        }

        const date = new Date(mail.tarih).toLocaleString('tr-TR');

        const embed = new EmbedBuilder()
            .setTitle(tip === 'gelen' ? '📥 Gelen Mail' : '📤 Giden Mail')
            .setColor(config.embedRenk || 0x34a853)
            .addFields(
                { name: 'ID', value: `\`${mail.id}\``, inline: true },
                { name: 'Konu', value: mail.konu || 'Yok', inline: true },
                { name: 'Tarih', value: date, inline: true },
                { name: 'Gönderen', value: `\`${mail.gonderenMail}\``, inline: true },
                { name: 'Alıcı', value: `\`${mail.aliciMail}\``, inline: true },
                { name: 'İçerik', value: mail.icerik || 'Boş', inline: false }
            );

        if (tip === 'gelen') {
            const idx = u.gelenKutusu.findIndex(m => m.id === id);
            if (idx !== -1) {
                u.gelenKutusu[idx].okundu = true;
                await db.set(`user_${interaction.user.id}`, u);
            }
        }

        return interaction.reply({ embeds: [embed], flags: 64 });
    }
};