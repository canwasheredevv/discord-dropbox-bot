import customtkinter as ctk
import subprocess
import threading
import time
import os
import sys
from datetime import datetime
from tkinter import filedialog, messagebox


# ==== AYARLAR ====
NODE_PATH_DEFAULT = "node"      # Gerekirse tam path: r"C:\Program Files\nodejs\node.exe"
BOT_FILE_DEFAULT = "index.js"   # Botun ana dosyası
LOG_FILE_DEFAULT = "bot_log.txt"


class BotController:
    def __init__(self):
        self.node_path = NODE_PATH_DEFAULT
        self.bot_file = BOT_FILE_DEFAULT
        self.log_file = LOG_FILE_DEFAULT

        self.process: subprocess.Popen | None = None
        self.auto_restart = False
        self.log_callback = None  # GUI içinden atanacak

        self._log_lock = threading.Lock()

    def log(self, text: str):
        """Hem dosyaya hem GUI'ye log yaz."""
        line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {text}"
        with self._log_lock:
            # Dosyaya yaz
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
            except Exception:
                pass

        # GUI callback
        if self.log_callback:
            self.log_callback(line)

    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def start_bot(self):
        if self.is_running():
            self.log("⚠️ Bot zaten çalışıyor.")
            return False

        if not os.path.exists(self.bot_file):
            self.log(f"❌ Bot dosyası bulunamadı: {self.bot_file}")
            return False

        try:
            self.log(f"🚀 Bot başlatılıyor... ({self.node_path} {self.bot_file})")
            self.process = subprocess.Popen(
                [self.node_path, self.bot_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            threading.Thread(target=self._read_logs_thread, daemon=True).start()
            self.log("✅ Bot başlatıldı.")
            return True
        except Exception as e:
            self.log(f"❌ Bot başlatılırken hata: {e}")
            return False

    def stop_bot(self):
        if not self.is_running():
            self.log("⚠️ Bot zaten çalışmıyor.")
            return False

        try:
            self.log("🛑 Bot kapatılıyor...")
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.log("✅ Bot kapatıldı.")
            return True
        except Exception as e:
            self.log(f"❌ Bot kapatılırken hata: {e}")
            return False

    def restart_bot(self):
        self.log("🔁 Bot yeniden başlatılıyor...")
        self.stop_bot()
        time.sleep(1)
        self.start_bot()

    def send_input(self, text: str):
        if not self.is_running():
            self.log("⚠️ Bot çalışmıyor. Komut gönderilemedi.")
            return False

        try:
            self.process.stdin.write(text + "\n")
            self.process.stdin.flush()
            self.log(f"💬 Bota gönderildi (stdin): {text}")
            return True
        except Exception as e:
            self.log(f"❌ Mesaj gönderilirken hata: {e}")
            return False

    def _read_logs_thread(self):
        if not self.process or not self.process.stdout:
            return

        for line in self.process.stdout:
            line = line.rstrip("\n")
            if not line:
                continue
            self.log(f"[BOT] {line}")

        code = self.process.poll()
        self.log(f"⚠️ Bot process sonlandı. Kod: {code}")

        if self.auto_restart:
            self.log("♻️ Otomatik yeniden başlatma aktif. 5 sn içinde tekrar başlatılıyor...")
            time.sleep(5)
            self.start_bot()


class BotControlPanel(ctk.CTk):
    def __init__(self, controller: BotController):
        super().__init__()

        self.controller = controller
        self.controller.log_callback = self.append_log

        # === PENCERE TEMEL AYARLAR ===
        ctk.set_appearance_mode("dark")  # "dark" / "light" / "system"
        ctk.set_default_color_theme("blue")  # green / dark-blue / blue

        self.title("Discord Bot Kontrol Paneli")
        self.geometry("1100x650")
        self.minsize(900, 550)

        # Ana grid
        self.grid_columnconfigure(0, weight=0)   # sol panel
        self.grid_columnconfigure(1, weight=1)   # sağ ana içerik
        self.grid_rowconfigure(0, weight=1)

        # SOL MENÜ
        self.sidebar_frame = ctk.CTkFrame(self, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, sticky="nsw")
        self.sidebar_frame.grid_rowconfigure(5, weight=1)

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="BOT PANEL", font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))

        self.status_indicator = ctk.CTkLabel(self.sidebar_frame, text="Durum: BİLİNMİYOR", fg_color="gray30",
                                             corner_radius=8, padx=10, pady=5)
        self.status_indicator.grid(row=1, column=0, padx=20, pady=(0, 15), sticky="ew")

        self.start_button = ctk.CTkButton(self.sidebar_frame, text="Başlat", command=self.start_bot)
        self.start_button.grid(row=2, column=0, padx=20, pady=5, sticky="ew")

        self.stop_button = ctk.CTkButton(self.sidebar_frame, text="Durdur", command=self.stop_bot)
        self.stop_button.grid(row=3, column=0, padx=20, pady=5, sticky="ew")

        self.restart_button = ctk.CTkButton(self.sidebar_frame, text="Yeniden Başlat", command=self.restart_bot)
        self.restart_button.grid(row=4, column=0, padx=20, pady=5, sticky="ew")

        # Alt kısım: tema / çıkış
        self.appearance_mode_optionemenu = ctk.CTkOptionMenu(
            self.sidebar_frame, values=["Dark", "Light", "System"],
            command=self.change_appearance_mode
        )
        self.appearance_mode_optionemenu.set("Dark")
        self.appearance_mode_optionemenu.grid(row=6, column=0, padx=20, pady=(10, 5), sticky="ew")

        self.exit_button = ctk.CTkButton(self.sidebar_frame, text="Paneli Kapat", fg_color="red", command=self.on_exit)
        self.exit_button.grid(row=7, column=0, padx=20, pady=(5, 20), sticky="ew")

        # SAĞ ANA ALAN: TABVIEW
        self.tabview = ctk.CTkTabview(self)
        self.tabview.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)

        self.tab_status = self.tabview.add("Durum")
        self.tab_console = self.tabview.add("Log / Konsol")
        self.tab_settings = self.tabview.add("Ayarlar")

        # === DURUM TABİ ===
        self._build_status_tab()

        # === LOG / KONSOL TABİ ===
        self._build_console_tab()

        # === AYARLAR TABİ ===
        self._build_settings_tab()

        # Durum güncelleme loop
        self.after(1000, self.update_status_loop)

    # -------------- UI Builders --------------

    def _build_status_tab(self):
        self.tab_status.grid_columnconfigure(0, weight=1)
        self.tab_status.grid_columnconfigure(1, weight=1)
        self.tab_status.grid_rowconfigure(0, weight=1)

        # Sol kısım: genel bilgiler
        self.info_frame = ctk.CTkFrame(self.tab_status)
        self.info_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        self.info_frame.grid_columnconfigure(0, weight=1)

        self.info_label = ctk.CTkLabel(
            self.info_frame,
            text="Bot Durumu",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        self.info_label.grid(row=0, column=0, padx=10, pady=(10, 5), sticky="w")

        self.info_text = ctk.CTkTextbox(self.info_frame, height=200)
        self.info_text.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
        self.info_text.insert("end", "Bot durumu burada görünecek.\n")
        self.info_text.configure(state="disabled")

        # Sağ kısım: hızlı kontroller, komut gönderme
        self.control_frame = ctk.CTkFrame(self.tab_status)
        self.control_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        self.control_frame.grid_columnconfigure(0, weight=1)

        self.auto_restart_switch = ctk.CTkSwitch(
            self.control_frame,
            text="Otomatik Yeniden Başlatma",
            command=self.toggle_auto_restart
        )
        self.auto_restart_switch.grid(row=0, column=0, padx=10, pady=(10, 10), sticky="w")

        self.command_entry = ctk.CTkEntry(self.control_frame, placeholder_text="Bota gönderilecek komut/mesaj (stdin)")
        self.command_entry.grid(row=1, column=0, padx=10, pady=(10, 5), sticky="ew")

        self.command_send_button = ctk.CTkButton(self.control_frame, text="Komut Gönder", command=self.send_command)
        self.command_send_button.grid(row=2, column=0, padx=10, pady=(0, 10), sticky="ew")

        self.note_label = ctk.CTkLabel(
            self.control_frame,
            text="Not: Bota stdin ile komut göndermek için index.js içinde\nprocess.stdin.on(...) kullanabilirsin.",
            justify="left",
            font=ctk.CTkFont(size=11)
        )
        self.note_label.grid(row=3, column=0, padx=10, pady=(5, 10), sticky="w")

    def _build_console_tab(self):
        self.tab_console.grid_rowconfigure(0, weight=1)
        self.tab_console.grid_columnconfigure(0, weight=1)

        self.log_textbox = ctk.CTkTextbox(self.tab_console)
        self.log_textbox.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        self.log_buttons_frame = ctk.CTkFrame(self.tab_console)
        self.log_buttons_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        self.log_buttons_frame.grid_columnconfigure(0, weight=1)
        self.log_buttons_frame.grid_columnconfigure(1, weight=1)
        self.log_buttons_frame.grid_columnconfigure(2, weight=1)

        self.clear_log_button = ctk.CTkButton(self.log_buttons_frame, text="Log'u Temizle", command=self.clear_log_view)
        self.clear_log_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        self.open_log_file_button = ctk.CTkButton(self.log_buttons_frame, text="Log Dosyasını Aç", command=self.open_log_file)
        self.open_log_file_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        self.refresh_log_button = ctk.CTkButton(self.log_buttons_frame, text="Son Logları Göster", command=self.load_log_file_tail)
        self.refresh_log_button.grid(row=0, column=2, padx=5, pady=5, sticky="ew")

    def _build_settings_tab(self):
        self.tab_settings.grid_columnconfigure(0, weight=1)

        # Node path
        self.node_label = ctk.CTkLabel(self.tab_settings, text="Node Yolu (node.exe):")
        self.node_label.grid(row=0, column=0, padx=10, pady=(10, 0), sticky="w")
        self.node_entry = ctk.CTkEntry(self.tab_settings)
        self.node_entry.grid(row=1, column=0, padx=10, pady=(0, 10), sticky="ew")
        self.node_entry.insert(0, self.controller.node_path)

        self.node_browse_button = ctk.CTkButton(self.tab_settings, text="Gözat", command=self.browse_node)
        self.node_browse_button.grid(row=1, column=1, padx=10, pady=(0, 10), sticky="ew")

        # Bot file
        self.bot_label = ctk.CTkLabel(self.tab_settings, text="Bot Ana Dosyası (index.js):")
        self.bot_label.grid(row=2, column=0, padx=10, pady=(10, 0), sticky="w")
        self.bot_entry = ctk.CTkEntry(self.tab_settings)
        self.bot_entry.grid(row=3, column=0, padx=10, pady=(0, 10), sticky="ew")
        self.bot_entry.insert(0, self.controller.bot_file)

        self.bot_browse_button = ctk.CTkButton(self.tab_settings, text="Gözat", command=self.browse_bot_file)
        self.bot_browse_button.grid(row=3, column=1, padx=10, pady=(0, 10), sticky="ew")

        # Log file
        self.log_label = ctk.CTkLabel(self.tab_settings, text="Log Dosyası:")
        self.log_label.grid(row=4, column=0, padx=10, pady=(10, 0), sticky="w")
        self.log_entry = ctk.CTkEntry(self.tab_settings)
        self.log_entry.grid(row=5, column=0, padx=10, pady=(0, 10), sticky="ew")
        self.log_entry.insert(0, self.controller.log_file)

        self.log_browse_button = ctk.CTkButton(self.tab_settings, text="Gözat", command=self.browse_log_file)
        self.log_browse_button.grid(row=5, column=1, padx=10, pady=(0, 10), sticky="ew")

        # Kaydet butonu
        self.save_settings_button = ctk.CTkButton(self.tab_settings, text="Ayarları Uygula", command=self.apply_settings)
        self.save_settings_button.grid(row=6, column=0, padx=10, pady=(10, 10), sticky="ew")

    # -------------- Event Handlers --------------

    def change_appearance_mode(self, new_mode: str):
        ctk.set_appearance_mode(new_mode.lower())

    def start_bot(self):
        self.apply_settings()  # son ayarları al
        ok = self.controller.start_bot()
        if not ok:
            messagebox.showerror("Hata", "Bot başlatılamadı. Detay için log'u kontrol et.")
        self.update_status_once()

    def stop_bot(self):
        ok = self.controller.stop_bot()
        if not ok:
            messagebox.showinfo("Bilgi", "Bot zaten çalışmıyor.")
        self.update_status_once()

    def restart_bot(self):
        self.apply_settings()
        self.controller.restart_bot()
        self.update_status_once()

    def toggle_auto_restart(self):
        self.controller.auto_restart = bool(self.auto_restart_switch.get())
        durum = "AÇIK" if self.controller.auto_restart else "KAPALI"
        self.controller.log(f"Otomatik yeniden başlatma: {durum}")

    def send_command(self):
        cmd = self.command_entry.get().strip()
        if not cmd:
            messagebox.showinfo("Bilgi", "Gönderilecek komut boş olamaz.")
            return
        self.controller.send_input(cmd)
        self.command_entry.delete(0, "end")

    def apply_settings(self):
        self.controller.node_path = self.node_entry.get().strip() or NODE_PATH_DEFAULT
        self.controller.bot_file = self.bot_entry.get().strip() or BOT_FILE_DEFAULT
        self.controller.log_file = self.log_entry.get().strip() or LOG_FILE_DEFAULT

    def browse_node(self):
        path = filedialog.askopenfilename(
            title="node.exe seç",
            filetypes=[("node.exe", "node.exe"), ("Tüm Dosyalar", "*.*")]
        )
        if path:
            self.node_entry.delete(0, "end")
            self.node_entry.insert(0, path)

    def browse_bot_file(self):
        path = filedialog.askopenfilename(
            title="Bot ana dosyasını seç (index.js)",
            filetypes=[("JavaScript Files", "*.js"), ("Tüm Dosyalar", "*.*")]
        )
        if path:
            self.bot_entry.delete(0, "end")
            self.bot_entry.insert(0, path)

    def browse_log_file(self):
        path = filedialog.asksaveasfilename(
            title="Log dosyası seç/oluştur",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("Tüm Dosyalar", "*.*")]
        )
        if path:
            self.log_entry.delete(0, "end")
            self.log_entry.insert(0, path)

    def clear_log_view(self):
        self.log_textbox.configure(state="normal")
        self.log_textbox.delete("1.0", "end")
        self.log_textbox.configure(state="disabled")

    def open_log_file(self):
        path = self.controller.log_file
        if not os.path.exists(path):
            messagebox.showinfo("Bilgi", "Henüz log dosyası yok.")
            return
        if os.name == "nt":
            os.startfile(path)
        else:
            subprocess.call(["xdg-open", path])

    def load_log_file_tail(self, lines: int = 200):
        path = self.controller.log_file
        if not os.path.exists(path):
            messagebox.showinfo("Bilgi", "Henüz log dosyası yok.")
            return

        try:
            with open(path, "r", encoding="utf-8") as f:
                all_lines = f.readlines()
            tail = "".join(all_lines[-lines:])

            self.log_textbox.configure(state="normal")
            self.log_textbox.delete("1.0", "end")
            self.log_textbox.insert("end", tail)
            self.log_textbox.see("end")
            self.log_textbox.configure(state="disabled")
        except Exception as e:
            messagebox.showerror("Hata", f"Log okunamadı: {e}")

    def append_log(self, line: str):
        # Bu fonksiyon arka thread'den çağrılıyor olabilir; main thread'e schedule et
        def _append():
            self.log_textbox.configure(state="normal")
            self.log_textbox.insert("end", line + "\n")
            self.log_textbox.see("end")
            self.log_textbox.configure(state="disabled")
        self.after(0, _append)

        # Durum tabındaki info da güncellensin diye basit bir özet
        def _info_append():
            self.info_text.configure(state="normal")
            self.info_text.insert("end", line + "\n")
            self.info_text.see("end")
            self.info_text.configure(state="disabled")
        self.after(0, _info_append)

    def update_status_once(self):
        running = self.controller.is_running()
        text = f"Durum: {'ÇALIŞIYOR' if running else 'DURDU'}"
        color = "green" if running else "red"

        self.status_indicator.configure(text=text, fg_color=color)

    def update_status_loop(self):
        self.update_status_once()
        self.after(1000, self.update_status_loop)

    def on_exit(self):
        if self.controller.is_running():
            if not messagebox.askyesno("Çıkış", "Bot hala çalışıyor. Kapatmak istiyor musun?"):
                return
            self.controller.stop_bot()
        self.destroy()


if __name__ == "__main__":
    controller = BotController()
    app = BotControlPanel(controller)
    app.mainloop()