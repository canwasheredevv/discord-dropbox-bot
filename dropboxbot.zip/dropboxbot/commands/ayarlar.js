const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('ayarlar')
        .setDescription('Profil, gizlilik ve sosyal ayarlarını yönet.'),

    /**
     * @param {import('discord.js').ChatInputCommandInteraction} interaction
     * @param {*} db
     */
    async execute(interaction, db) {
        const u = await db.get(`user_${interaction.user.id}`);
        if (!u) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        // Varsayılan alanlar
        u.bio = u.bio || "";
        u.mailGizli = !!u.mailGizli;
        u.tarihGizli = !!u.tarihGizli;
        u.dosyalar = u.dosyalar || [];
        u.gelenKutusu = u.gelenKutusu || [];
        u.gidenKutusu = u.gidenKutusu || [];
        u.takipci = u.takipci || [];
        u.takip = u.takip || [];
        u.engellediklerim = u.engellediklerim || [];

        const gelenSayisi = u.gelenKutusu.length;
        const gidenSayisi = u.gidenKutusu.length;
        const okunmamis = u.gelenKutusu.filter(m => !m.okundu).length;
        const takipciSayisi = u.takipci.length;
        const takipSayisi = u.takip.length;
        const engelSayisi = u.engellediklerim.length;

        // SAYFA 1: Genel Profil Ayarları
        const page1 = new EmbedBuilder()
            .setTitle(`⚙️ Profil Ayarları | ${u.isim} (@${interaction.user.username})`)
            .setColor(config.embedRenk || 0x34a853)
            .setThumbnail(interaction.user.displayAvatarURL())
            .addFields(
                {
                    name: "📝 Biyografi",
                    value: u.bio ? `\`${u.bio}\`` : "Henüz bir biyografi yazılmamış.",
                    inline: false
                },
                {
                    name: "📧 Mail Görünürlüğü",
                    value: u.mailGizli
                        ? "Şu an: **Gizli** (profilde gizli gösteriliyor)"
                        : "Şu an: **Görünür** (profilde açık gösteriliyor)",
                    inline: true
                },
                {
                    name: "📅 Doğum Tarihi Görünürlüğü",
                    value: u.tarihGizli
                        ? "Şu an: **Gizli** (profilde gizli gösteriliyor)"
                        : "Şu an: **Görünür** (profilde açık gösteriliyor)",
                    inline: true
                },
                {
                    name: "🔑 Yükleme Hakkı",
                    value: `Şu an: **${u.hak}** hak`,
                    inline: true
                },
                {
               name: "📬 Mail Kutusu",
               value:
                       `• Gelen: **${refreshedGelen}**\n` +
                       `• Giden: **${refreshedGiden}**\n` +
                       `• Okunmamış: **${refreshedOkunmamis}**`,
                 inline: true
                },
                {
                    name: "👥 Takip / Engel",
                    value:
                        `• Takipçi: **${takipciSayisi}**\n` +
                        `• Takip: **${takipSayisi}**\n` +
                        `• Engelli: **${engelSayisi}**`,
                    inline: true
                }
            )
            .setFooter({ text: "Sayfa 1/2 • Butonlarla ayarlarını değiştirebilirsin." })
            .setTimestamp();

        // SAYFA 2: Sosyal & Güvenlik
        const page2 = new EmbedBuilder()
            .setTitle(`🛡️ Sosyal & Güvenlik Ayarları | ${u.isim}`)
            .setColor(config.embedRenk || 0x34a853)
            .setThumbnail(interaction.user.displayAvatarURL())
            .addFields(
                {
                    name: "🚫 Engelli Liste",
                    value:
                        engelSayisi === 0
                            ? "Hiç kimseyi engellememişsin.\nEngellemek için: `/engelle mail@dropbox.bot`"
                            : `Toplam **${engelSayisi}** kullanıcıyı engellemişsin.\nDetay için: \`/engel-liste\``,
                    inline: false
                },
                {
                    name: "👥 Takipçi Bilgisi",
                    value:
                        takipciSayisi === 0
                            ? "Henüz takipçin yok."
                            : `Seni takip eden **${takipciSayisi}** kullanıcı var.\nDetay komutlarını eklemek istersen `/takipcilerim` gibi komutlar yazılabilir.`,
                    inline: false
                },
                {
                    name: "📌 Takip Ettiklerin",
                    value:
                        takipSayisi === 0
                            ? "Kimseyi takip etmiyorsun."
                            : `Toplam **${takipSayisi}** kullanıcıyı takip ediyorsun.\nTakip eklemek: \`/takipet mail@dropbox.bot\`\nTakipten çıkmak: \`/takipcik mail@dropbox.bot\``,
                    inline: false
                }
            )
            .setFooter({ text: "Sayfa 2/2 • Sosyal ve güvenlik odaklı ayarlar.", iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        const pages = [page1, page2];
        let currentPage = 0;

        const makeRow = () => new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('ayarlar_prev')
                .setLabel('◀️ Geri')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(currentPage === 0),

            new ButtonBuilder()
                .setCustomId('ayarlar_bio')
                .setLabel('📝 Biyografi')
                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId('ayarlar_mail_toggle')
                .setLabel(u.mailGizli ? '📧 Maili Görünür Yap' : '📧 Maili Gizle')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId('ayarlar_tarih_toggle')
                .setLabel(u.tarihGizli ? '📅 Tarihi Görünür Yap' : '📅 Tarihi Gizle')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId('ayarlar_next')
                .setLabel('İleri ▶️')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(currentPage === pages.length - 1)
        );

        const socialRow = () => new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('ayarlar_engel_liste')
                .setLabel('🚫 Engelli Liste')
                .setStyle(ButtonStyle.Danger),

            new ButtonBuilder()
                .setCustomId('ayarlar_hak')
                .setLabel('🔑 Yükleme Hakkım')
                .setStyle(ButtonStyle.Success)
        );

        const msg = await interaction.reply({
            embeds: [pages[currentPage]],
            components: [makeRow(), socialRow()],
            flags: 64 // sadece kullanıcı görsün
        });

        const collector = msg.createMessageComponentCollector({
            time: 1000 * 60 * 5 // 5 dakika
        });

        collector.on('collect', async (btn) => {
            if (btn.user.id !== interaction.user.id) {
                return btn.reply({
                    content: 'Bu ayar menüsünü sadece komutu kullanan kişi kontrol edebilir.',
                    flags: 64
                });
            }

            const customId = btn.customId;
            let userData = await db.get(`user_${interaction.user.id}`);
            if (!userData) {
                return btn.reply({
                    content: 'Kullanıcı verin bulunamadı. Lütfen tekrar kayıt ol.',
                    flags: 64
                });
            }

            userData.engellediklerim = userData.engellediklerim || [];
            userData.takipci = userData.takipci || [];
            userData.takip = userData.takip || [];
            userData.gelenKutusu = userData.gelenKutusu || [];
            userData.gidenKutusu = userData.gidenKutusu || [];
            userData.dosyalar = userData.dosyalar || [];

            // SAYFA DEĞİŞTİRME
            if (customId === 'ayarlar_prev') {
                if (currentPage > 0) currentPage--;
            } else if (customId === 'ayarlar_next') {
                if (currentPage < pages.length - 1) currentPage++;
            }

            // BİYOGRAFİ MODAL
            if (customId === 'ayarlar_bio') {
                const modal = new ModalBuilder()
                    .setCustomId('profil_ayar_bio_modal')
                    .setTitle('📝 Biyografi Değiştir');

                const bioInput = new TextInputBuilder()
                    .setCustomId('bio_input')
                    .setLabel('Yeni biyografin')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setMaxLength(200);

                const row1 = new ActionRowBuilder().addComponents(bioInput);
                modal.addComponents(row1);

                return btn.showModal(modal);
            }

            // MAIL GİZLİLİĞİ TOGGLE
            if (customId === 'ayarlar_mail_toggle') {
                userData.mailGizli = !userData.mailGizli;
                await db.set(`user_${interaction.user.id}`, userData);
            }

            // TARİH GİZLİLİĞİ TOGGLE
            if (customId === 'ayarlar_tarih_toggle') {
                userData.tarihGizli = !userData.tarihGizli;
                await db.set(`user_${interaction.user.id}`, userData);
            }

            // ENGEL LİSTE KISAYOLU
            if (customId === 'ayarlar_engel_liste') {
                if (userData.engellediklerim.length === 0) {
                    return btn.reply({
                        content: 'Hiç kimseyi engellememişsin.',
                        flags: 64
                    });
                }

                const lines = [];
                for (const targetId of userData.engellediklerim) {
                    const t = await db.get(`user_${targetId}`);
                    const mail = t?.mail || 'bilinmiyor';
                    const isim = t?.isim || 'Bilinmeyen Kullanıcı';
                    lines.push(`• **${isim}** \`<${mail}>\` (ID: \`${targetId}\`)`);
                }

                return btn.reply({
                    content: `🚫 Engellediklerin:\n${lines.join('\n')}`,
                    flags: 64
                });
            }

            // HAK GÖSTER
            if (customId === 'ayarlar_hak') {
                return btn.reply({
                    content: `Şu an **${userData.hak}** yükleme hakkın bulunuyor.`,
                    flags: 64
                });
            }

            // Embedleri güncelle (özellikle sayfa 1 değiştiyse)
            const refreshedU = userData;
            const refreshedGelen = refreshedU.gelenKutusu.length;
            const refreshedGiden = refreshedU.gidenKutusu.length;
            const refreshedOkunmamis = refreshedU.gelenKutusu.filter(m => !m.okundu).length;
            const refreshedTakipci = refreshedU.takipci.length;
            const refreshedTakip = refreshedU.takip.length;
            const refreshedEngel = refreshedU.engellediklerim.length;

            pages[0] = new EmbedBuilder()
                .setTitle(`⚙️ Profil Ayarları | ${refreshedU.isim} (@${interaction.user.username})`)
                .setColor(config.embedRenk || 0x34a853)
                .setThumbnail(interaction.user.displayAvatarURL())
                .addFields(
                    {
                        name: "📝 Biyografi",
                        value: refreshedU.bio ? `\`${refreshedU.bio}\`` : "Henüz bir biyografi yazılmamış.",
                        inline: false
                    },
                    {
                        name: "📧 Mail Görünürlüğü",
                        value: refreshedU.mailGizli
                            ? "Şu an: **Gizli** (profilde gizli gösteriliyor)"
                            : "Şu an: **Görünür** (profilde açık gösteriliyor)",
                        inline: true
                    },
                    {
                        name: "📅 Doğum Tarihi Görünürlüğü",
                        value: refreshedU.tarihGizli
                            ? "Şu an: **Gizli** (profilde gizli gösteriliyor)"
                            : "Şu an: **Görünür** (profilde açık gösteriliyor)",
                        inline: true
                    },
                    {
                        name: "🔑 Yükleme Hakkı",
                        value: `Şu an: **${refreshedU.hak}** hak`,
                        inline: true
                    },
                    {
                        name: "📬 Mail Kutusu",
                        value:
                            `• Gelen: **${refreshedGelen}**\n` +
                            `• Giden: **${refreshedGiden}**\n` +
                            `• Okunmamış: **${refreshedOkunmamais}**`,
                        inline: true
                    },
                    {
                        name: "👥 Takip / Engel",
                        value:
                            `• Takipçi: **${refreshedTakipci}**\n` +
                            `• Takip: **${refreshedTakip}**\n` +
                            `• Engelli: **${refreshedEngel}**`,
                        inline: true
                    }
                )
                .setFooter({ text: "Sayfa 1/2 • Butonlarla ayarlarını değiştirebilirsin." })
                .setTimestamp();

            pages[1] = new EmbedBuilder()
                .setTitle(`🛡️ Sosyal & Güvenlik Ayarları | ${refreshedU.isim}`)
                .setColor(config.embedRenk || 0x34a853)
                .setThumbnail(interaction.user.displayAvatarURL())
                .addFields(
                    {
                        name: "🚫 Engelli Liste",
                        value:
                            refreshedEngel === 0
                                ? "Hiç kimseyi engellememişsin.\nEngellemek için: `/engelle mail@dropbox.bot`"
                                : `Toplam **${refreshedEngel}** kullanıcıyı engellemişsin.\nDetay için: \`/engel-liste\``,
                        inline: false
                    },
                    {
                        name: "👥 Takipçi Bilgisi",
                        value:
                            refreshedTakipci === 0
                                ? "Henüz takipçin yok."
                                : `Seni takip eden **${refreshedTakipci}** kullanıcı var.`,
                        inline: false
                    },
                    {
                        name: "📌 Takip Ettiklerin",
                        value:
                            refreshedTakip === 0
                                ? "Kimseyi takip etmiyorsun."
                                : `Toplam **${refreshedTakip}** kullanıcıyı takip ediyorsun.\nTakip eklemek: \`/takipet mail@dropbox.bot\`\nTakipten çıkmak: \`/takipcik mail@dropbox.bot\``,
                        inline: false
                    }
                )
                .setFooter({ text: "Sayfa 2/2 • Sosyal ve güvenlik odaklı ayarlar.", iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            await btn.update({
                embeds: [pages[currentPage]],
                components: [makeRow(), socialRow()]
            });
        });

        collector.on('end', async () => {
            const disabledRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('ayarlar_prev')
                    .setLabel('◀️ Geri')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('ayarlar_bio')
                    .setLabel('📝 Biyografi')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('ayarlar_mail_toggle')
                    .setLabel('📧 Mail')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('ayarlar_tarih_toggle')
                    .setLabel('📅 Tarih')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('ayarlar_next')
                    .setLabel('İleri ▶️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            );

            const disabledSocialRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('ayarlar_engel_liste')
                    .setLabel('🚫 Engelli Liste')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('ayarlar_hak')
                    .setLabel('🔑 Yükleme Hakkım')
                    .setStyle(ButtonStyle.Success)
                    .setDisabled(true)
            );

            await msg.edit({
                components: [disabledRow, disabledSocialRow]
            }).catch(() => {});
        });
    }
};