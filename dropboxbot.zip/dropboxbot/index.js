const {
    Client,
    GatewayIntentBits,
    Collection,
    REST,
    Routes,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    EmbedBuilder,
    ActivityType
} = require('discord.js');
const fs = require('node:fs');
const { QuickDB } = require("quick.db"); //by katliamcxn calıp düzenleyip benden habersiz satanın amına koyayım oruspucocukları
const { Dropbox } = require('dropbox');
const fetch = require('node-fetch');
const config = require('./config.js');

const db = new QuickDB();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    rest: {
        timeout: 60000
    }
});

// --- DROPBOX CLIENT ---
const dbx = new Dropbox({
    accessToken: config.dropbox.accessToken,
    fetch
});

// --- KOMUT YÜKLEYİCİ ---
client.commands = new Collection();
const commands = [];
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

console.log("📂 Komutlar yükleniyor...");

for (const file of commandFiles) {
    const command = require(`./commands/${file}`);

    if (!command.data || !command.data.name || !command.data.description) {
        console.error(`❌ HATA: ${file} dosyasında 'name' veya 'description' eksik!`);
        continue;
    }

    try {
        client.commands.set(command.data.name, command);

        const json = command.data.toJSON();
        if (command.integration_types) json.integration_types = command.integration_types;
        if (command.contexts) json.contexts = command.contexts;

        commands.push(json);
        console.log(`✅ Yüklendi: /${command.data.name}`);
    } catch (error) {
        console.error(`❌ KRİTİK HATA: ${file} işlenemedi. Detay:`, error.message);
    }
}

// --- READY ---
client.once('ready', async () => {
    const rest = new REST({ version: '10' }).setToken(config.token);

    try {
        await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
        console.log(`🚀 ${client.user.tag} aktif! Komutlar Discord'a gönderildi.`);
    } catch (e) {
        console.error("Slash komutları kaydedilirken hata:", e);
    }

    console.log('========================================');
    console.log(`✅ Bot giriş yaptı: ${client.user.tag}`);
    console.log(`🌐 Sunucu sayısı : ${client.guilds.cache.size}`);
    console.log(`👤 Kullanıcı (cache): ${client.users.cache.size}`);
    console.log('========================================');

    // Durum ve aktivite
    client.user.setStatus('online');

    const getDynamicStats = () => {
        const guildCount = client.guilds.cache.size;
        const userCount = client.users.cache.size;
        const commandsCount = client.commands?.size || 0;
        return { guildCount, userCount, commandsCount };
    };

    const buildActivities = () => {
        const { guildCount, userCount, commandsCount } = getDynamicStats();
        return [
            {
                name: `/yardim ile ${commandsCount} komutu keşfet`,
                type: ActivityType.Playing
            },
            {
                name: `${guildCount} sunucuda hizmet veriyor`,
                type: ActivityType.Watching
            },
            {
                name: `${userCount} kullanıcıya bot içi mail taşıyor`,
                type: ActivityType.Listening
            },
            {
                name: 'DM üzerinden güvenli dosya iletimi',
                type: ActivityType.Playing
            },
            {
                name: 'profil, takip ve engel sistemini',
                type: ActivityType.Watching
            }
        ];
    };

    let actIndex = 0;
    const updatePresence = () => {
        const activities = buildActivities();
        if (!activities.length) return;
        const activity = activities[actIndex % activities.length];
        client.user.setActivity(activity.name, { type: activity.type });
        actIndex++;
    };

    updatePresence();
    setInterval(updatePresence, 30_000);

    // --- 3 SAATLİK OTOMATİK SİLME DÖNGÜSÜ ---
    setInterval(async () => {
        const allData = await db.all();
        const simdi = Date.now();

        for (const data of allData) {
            if (!data.id.startsWith('user_')) continue;

            const user = data.value;
            if (!user.dosyalar || user.dosyalar.length === 0) continue;

            const silinecekler = user.dosyalar.filter(d => d.silinmeTarihi && simdi > d.silinmeTarihi);
            if (silinecekler.length === 0) continue;

            const kalanlar = user.dosyalar.filter(d => !d.silinmeTarihi || simdi <= d.silinmeTarihi);

            for (const dosya of silinecekler) {
                try {
                    // DROPBOX'TAN SİL
                    if (dosya.dropboxPath) {
                        try {
                            await dbx.filesDeleteV2({ path: dosya.dropboxPath });
                        } catch (e) {
                            console.log(`Dropbox silme hatası (${dosya.dropboxPath}):`, e.message || e);
                        }
                    }

                    // KULLANICIYA DM
                    const dUser = await client.users.fetch(data.id.replace('user_', '')).catch(() => null);
                    if (dUser) {
                        dUser.send(`⏰ **Süre Doldu:** \`${dosya.ad}\` dosyanız 3 saatlik süresi dolduğu için **Dropbox hesabınızdan da** silindi.`)
                            .catch(() => null);
                    }
                } catch (e) {
                    console.log("Silme döngüsü hatası:", e.message);
                }
            }

            await db.set(`${data.id}.dosyalar`, kalanlar);
        }
    }, 60000);
});

// --- INTERACTION ---
client.on('interactionCreate', async (interaction) => {
    const userId = interaction.user.id;

    // LOG KANALINA EMBED GÖNDEREN FONKSİYON
    async function logToChannel(embed) {
        if (!config.logKanalID) return;

        let logChannel = null;

        // Önce interaction'ın sunucusundan dene
        if (interaction.guild) {
            logChannel = interaction.guild.channels.cache.get(config.logKanalID);
        }

        // Olmazsa global cache'ten dene (farklı sunucuda log kanalı kullanıyorsan)
        if (!logChannel) {
            logChannel = interaction.client.channels.cache.get(config.logKanalID);
        }

        if (!logChannel) return;

        try {
            await logChannel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Log kanalına mesaj gönderilemedi:', e.message);
        }
    }

    // 1) Slash komutlar
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        // === LOG EMBEDİ ===
        const now = new Date();
        const timestamp = now.toISOString().replace('T', ' ').split('.')[0];

        const guild = interaction.guild;
        const guildName = guild ? guild.name : 'DM / Uygulama';
        const guildId = guild ? guild.id : 'DM/Uygulama';

        const channel = interaction.channel;
        const channelName = channel ? (channel.name || channel.id) : 'Bilinmiyor';
        const channelId = channel ? channel.id : 'Bilinmiyor';

        const typeLabel = guild ? 'Sunucu' : 'Uygulama';

        const options = [];
        if (interaction.options?._hoistedOptions?.length) {
            for (const opt of interaction.options._hoistedOptions) {
                options.push(`\`${opt.name}\` = \`${opt.value}\``);
            }
        }
        const optionsString = options.length ? options.join('\n') : 'Yok';

        const logEmbed = new EmbedBuilder()
            .setTitle('📝 Komut Kullanım Logu') //by katliamcxn calıp düzenleyip benden habersiz satanın amına koyayım oruspucocukları
            .setColor(0x2f3136)
            .setThumbnail(interaction.user.displayAvatarURL())
            .addFields(
                {
                    name: 'Kullanıcı',
                    value: `**Tag:** ${interaction.user.tag}\n**ID:** \`${userId}\``,
                    inline: true
                },
                {
                    name: 'Komut',
                    value: `\`/${interaction.commandName}\``,
                    inline: true
                },
                {
                    name: 'Tür',
                    value: typeLabel,
                    inline: true
                },
                {
                    name: 'Sunucu',
                    value: `**İsim:** ${guildName}\n**ID:** \`${guildId}\``,
                    inline: false
                },
                {
                    name: 'Kanal',
                    value: `**İsim:** ${channelName}\n**ID:** \`${channelId}\``,
                    inline: false
                },
                {
                    name: 'Parametreler',
                    value: optionsString,
                    inline: false
                }
            )
            .setFooter({ text: `Zaman: ${timestamp}` });

        await logToChannel(logEmbed);
        // ====================

        try {
            await command.execute(interaction, db);
        } catch (error) {
            console.error(error);

            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: 'Komutu çalıştırırken bir hata oluştu.' });
                } else if (!interaction.deferred && !interaction.replied) {
                    await interaction.reply({
                        content: 'Komutu çalıştırırken bir hata oluştu.',
                        flags: 64 // ephemeral
                    });
                }
            } catch {
                // ikinci hatayı sessizce yut
            }
        }
        return;
    }

    // 2) Modal submit (kayıt + profil ayarları)
    if (interaction.isModalSubmit()) {
        // Kayıt modalı
        if (interaction.customId === 'kayit_modal') {
            const isim = interaction.fields.getTextInputValue('isim');
            const tarih = interaction.fields.getTextInputValue('dogum_tarihi');
            const mail = interaction.user.username
                .toLowerCase()
                .replace(/[^a-z0-9]/g, '') + config.botMailUzantisi;

            await db.set(`user_${userId}`, { //burayı sakın elleme patlar bot
                isim,
                dogumTarihi: tarih,
                mail,
                dosyalar: [],
                gecmis: [],
                hak: config.varsayilanHak,
                sonYenileme: "Yok",
                bio: "",
                mailGizli: false,
                tarihGizli: false,
                gelenKutusu: [],
                gidenKutusu: [],
                takipci: [],
                takip: [],
                engellediklerim: []
            });
            await db.set(`mail_${mail}`, userId); //by katliamcxn calıp düzenleyip benden habersiz satanın amına koyayım oruspucocukları

            return interaction.reply({
                content: `✅ Kayıt başarılı! Mailin: \`${mail}\``,
                flags: 64
            });
        }

        // Profil ayarları - biyografi modalı
        if (interaction.customId === 'profil_ayar_bio_modal') {
            const newBio = interaction.fields.getTextInputValue('bio_input') || null;

            const u = await db.get(`user_${interaction.user.id}`);
            if (!u) {
                return interaction.reply({
                    content: 'Kullanıcı verin bulunamadı. Lütfen tekrar kayıt ol.',
                    flags: 64
                });
            }

            u.bio = newBio;
            await db.set(`user_${interaction.user.id}`, u);

            return interaction.reply({
                content: newBio
                    ? `Biyografin başarıyla güncellendi:\n\`${newBio}\``
                    : 'Biyografin temizlendi.',
                flags: 64
            });
        }

        return;
    }

    // 3) Butonlar
    if (interaction.isButton()) {
        // Profil ayarları butonu
        if (interaction.customId.startsWith('ayarlar_')) {
            const ownerId = interaction.customId.split('_')[1];

            if (ownerId !== interaction.user.id) {
                return interaction.reply({
                    content: 'Bu profil ayarları butonu sana ait değil.',
                    flags: 64
                });
            }

            const settingsCommand = client.commands.get('ayarlar');
            if (!settingsCommand) {
                return interaction.reply({
                    content: 'Ayarlar komutu bulunamadı. Lütfen bot sahibine bildir.',
                    flags: 64
                });
            }

            try {
                await settingsCommand.execute(interaction, db);
            } catch (e) {
                console.error('Ayarlar butonu çalıştırılırken hata:', e);
                try {
                    if (interaction.deferred && !interaction.replied) {
                        await interaction.editReply({ content: 'Ayarlar açılırken bir hata oluştu.' });
                    } else if (!interaction.deferred && !interaction.replied) {
                        await interaction.reply({
                            content: 'Ayarlar açılırken bir hata oluştu.',
                            flags: 64
                        });
                    }
                } catch {}
            }

            return;
        }

        // Dosya onay butonu
        if (interaction.customId.startsWith('onay_')) {
            const [, kod, gId] = interaction.customId.split('_');
            const gData = await db.get(`user_${gId}`);
            if (!gData || !Array.isArray(gData.dosyalar)) {
                return interaction.reply({ content: "Kullanıcı veya dosya verisi bulunamadı.", flags: 64 });
            }

            const dosya = gData.dosyalar.find(d => d.id === kod);
            if (!dosya) {
                return interaction.reply({ content: "Dosya artık mevcut değil.", flags: 64 });
            }

            return interaction.reply({
                content: `✅ Dosya kabul edildi!\n**Link:** ${dosya.url}`
            });
        }

        return;
    }
});

//by katliamcxn calıp düzenleyip benden habersiz satanın amına koyayım oruspucocukları
client.login(config.token);