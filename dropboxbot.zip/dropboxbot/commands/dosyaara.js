const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder().setName('dosya-ara').setDescription('Sürücünüzde dosya arayın.').addStringOption(o => o.setName('isim').setRequired(true).setDescription('Aranacak kelime')),
    async execute(interaction, db) {
        const data = await db.get(`user_${interaction.user.id}`);
        const sonuclar = data.dosyalar.filter(d => d.ad.toLowerCase().includes(interaction.options.getString('isim').toLowerCase()));
        if (!sonuclar.length) return interaction.reply("Eşleşen dosya bulunamadı.");
        await interaction.reply(`🔍 Bulunan Dosyalar:\n${sonuclar.map(d => `\`${d.id}\` - ${d.ad}`).join('\n')}`);
    }
};
