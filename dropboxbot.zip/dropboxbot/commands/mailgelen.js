const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-gelen')
        .setDescription('Gelen kutundaki mailleri gösterir.'),

    async execute(interaction, db) {
        const u = await db.get(`user_${interaction.user.id}`);
        if (!u) {
            return interaction.reply({ content: "Önce `/hesap-olustur` ile kayıt olmalısın!", flags: 64 });
        }

        u.gelenKutusu = u.gelenKutusu || [];
        const mails = [...u.gelenKutusu].sort((a, b) => b.tarih - a.tarih).slice(0, 10);

        if (mails.length === 0) {
            return interaction.reply({ content: "Gelen kutunda hiç mail yok.", flags: 64 });
        }

        const embed = new EmbedBuilder()
            .setTitle('📥 Gelen Kutusu')
            .setColor(config.embedRenk || 0x34a853)
            .setThumbnail(interaction.user.displayAvatarURL())
            .setDescription(
                mails.map(m => {
                    const date = new Date(m.tarih).toLocaleString('tr-TR');
                    return `**ID:** \`${m.id}\`\n**Gönderen:** \`${m.gonderenMail}\`\n**Konu:** ${m.konu}\n**Tarih:** ${date}\n**Durum:** ${m.okundu ? '✅ Okundu' : '📩 Okunmadı'}`;
                }).join('\n────────────\n')
            )
            .setFooter({ text: "Detay için /mail-oku id:<mail_id>" });

        return interaction.reply({ embeds: [embed], flags: 64 });
    }
};