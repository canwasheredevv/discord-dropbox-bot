const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sifirla')
        .setDescription('Hesabınızı ve tüm dosyalarınızı tamamen siler (Geri döndürülemez).'),
    async execute(interaction, db) {
        const userData = await db.get(`user_${interaction.user.id}`);
        if (!userData) return interaction.reply({ content: "Zaten bir hesabınız bulunmuyor.", ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle("⚠️ Hesabı Sıfırla")
            .setDescription(`**${userData.isim}**, hesabını ve sürücündeki tüm dosyaları silmek istediğine emin misin? \n\n**Mail:** \`${userData.mail}\` \n**Dosya Sayısı:** \`${userData.dosyalar.length}\` \n\n*Bu işlem geri alınamaz!*`)
            .setColor("#ff0000");

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('sifirla_onay')
                .setLabel('Evet, Her Şeyi Sil')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('sifirla_iptal')
                .setLabel('Vazgeç')
                .setStyle(ButtonStyle.Secondary)
        );

        const response = await interaction.reply({
            embeds: [embed],
            components: [row],
            ephemeral: true
        });

        // Buton tıklamasını dinleyen basit bir toplayıcı (Collector)
        const collectorFilter = i => i.user.id === interaction.user.id;
        try {
            const confirmation = await response.awaitMessageComponent({ filter: collectorFilter, time: 30000 });

            if (confirmation.customId === 'sifirla_onay') {
                // Veritabanından temizle
                await db.delete(`mail_${userData.mail}`);
                await db.delete(`user_${interaction.user.id}`);

                await confirmation.update({ 
                    content: "✅ Hesabınız ve tüm verileriniz başarıyla silindi. Tekrar görüşmek üzere!", 
                    embeds: [], 
                    components: [] 
                });
            } else if (confirmation.customId === 'sifirla_iptal') {
                await confirmation.update({ 
                    content: "❌ İşlem iptal edildi. Verileriniz güvende.", 
                    embeds: [], 
                    components: [] 
                });
            }
        } catch (e) {
            await interaction.editReply({ content: 'Süre dolduğu için işlem iptal edildi.', components: [], embeds: [] });
        }
    },
};
