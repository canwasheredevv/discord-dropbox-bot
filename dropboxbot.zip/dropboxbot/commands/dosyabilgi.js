const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder().setName('dosya-bilgi').setDescription('Dosyanın detaylarını gösterir.').addStringOption(o => o.setName('kod').setRequired(true).setDescription('Dosya kodu')),
    async execute(interaction, db) {
        const data = await db.get(`user_${interaction.user.id}`);
        const dosya = data.dosyalar.find(d => d.id === interaction.options.getString('kod').toUpperCase());
        if (!dosya) return interaction.reply("Dosya bulunamadı.");
        const embed = new EmbedBuilder().setTitle(`📄 ${dosya.ad}`).addFields({name: "Kod", value: dosya.id, inline: true}, {name: "Boyut", value: dosya.boyut, inline: true}).setColor("#34a853");
        await interaction.reply({ embeds: [embed] });
    }
};
