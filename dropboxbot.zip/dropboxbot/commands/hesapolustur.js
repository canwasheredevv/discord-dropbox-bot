const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('hesap-olustur')
        .setDescription('DropBox hesabınızı isim ve doğum tarihi ile oluşturun.'),
        
    async execute(interaction, db) {
        const userExists = await db.get(`user_${interaction.user.id}`);
        if (userExists) {
            return interaction.reply({ content: "Zaten bir hesabınız var!", flags: 64 });
        }

        const modal = new ModalBuilder()
            .setCustomId('kayit_modal')
            .setTitle('DropBox Kayıt Paneli');

        const isimInput = new TextInputBuilder()
            .setCustomId('isim')
            .setLabel("Adınız ve Soyadınız")
            .setPlaceholder("Örn: Can Yılmaz")
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        const tarihInput = new TextInputBuilder()
            .setCustomId('dogum_tarihi')
            .setLabel("Doğum Tarihiniz (GG.AA.YYYY)")
            .setPlaceholder("Örn: 01.01.2000")
            .setMinLength(10)
            .setMaxLength(10)
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        modal.addComponents(
            new ActionRowBuilder().addComponents(isimInput),
            new ActionRowBuilder().addComponents(tarihInput)
        );
        
        await interaction.showModal(modal);
    },
};