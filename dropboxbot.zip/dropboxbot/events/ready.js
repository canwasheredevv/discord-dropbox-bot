const { ActivityType, Events } = require('discord.js');
const config = require('../config.js');

module.exports = {
    name: Events.ClientReady,
    once: true,

    /**
     * @param {import('discord.js').Client} client
     */
    execute(client) {
        console.log('========================================');
        console.log(`✅ Bot giriş yaptı: ${client.user.tag}`);
        console.log(`🌐 Sunucu sayısı : ${client.guilds.cache.size}`);
        console.log(`👤 Kullanıcı (cache): ${client.users.cache.size}`);
        console.log('========================================');

        // Durum: online | idle | dnd | invisible
        client.user.setStatus('online');

        // Dinamik değerleri hesaplayan fonksiyon
        const getDynamicStats = () => {
            const guildCount = client.guilds.cache.size;
            const userCount = client.users.cache.size;
            const channelCount = client.channels.cache.size;
            const commandsCount = client.commands?.size || 0;

            return { guildCount, userCount, channelCount, commandsCount };
        };

        // Aktivite listesi (döngü ile sırayla gösterilecek)
        const buildActivities = () => {
            const { guildCount, userCount, channelCount, commandsCount } = getDynamicStats();

            return [
                {
                    name: `/yardim ile ${commandsCount} komutu keşfet`,
                    type: ActivityType.Playing
                },
                {
                    name: `${guildCount} sunucuda hizmet veriyor`,
                    type: ActivityType.Watching
                },
                {
                    name: `${userCount} kullanıcıya mail taşıyor`,
                    type: ActivityType.Listening
                },
                {
                    name: 'DM üzerinden güvenli dosya iletimi',
                    type: ActivityType.Playing
                },
                {
                    name: 'https://github.com/canwasheredevv',
                    type: ActivityType.Watching
                }
            ];
        };

        let index = 0;
        const updatePresence = () => {
            const activities = buildActivities();
            if (activities.length === 0) return;

            const activity = activities[index % activities.length];
            client.user.setActivity(activity.name, { type: activity.type });

            index++;
        };

        // İlk ayarla
        updatePresence();
        // Her 30 saniyede bir aktiviteyi güncelle
        setInterval(updatePresence, 30_000);
    }
};