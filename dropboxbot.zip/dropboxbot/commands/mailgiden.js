const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-giden')
        .setDescription('Gönderdiğin mailleri gösterir.'),

    async execute(interaction, db) {
        const u = await db.get(`user_${interaction.user.id}`);
        if (!u) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        u.gidenKutusu = u.gidenKutusu || [];
        const mails = [...u.gidenKutusu].sort((a, b) => b.tarih - a.tarih).slice(0, 10);

        if (mails.length === 0) {
            return interaction.reply({
                content: "Henüz hiç mail göndermemişsin.",
                flags: 64
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('📤 Giden Kutusu')
            .setColor(config.embedRenk || 0x34a853)
            .setThumbnail(interaction.user.displayAvatarURL())
            .setDescription(
                mails.map(m => {
                    const date = new Date(m.tarih).toLocaleString('tr-TR');
                    return `**ID:** \`${m.id}\`\n**Alıcı:** \`${m.aliciMail}\`\n**Konu:** ${m.konu}\n**Tarih:** ${date}`;
                }).join('\n────────────\n')
            )
            .setFooter({ text: "Detay için /mail-oku id:<mail_id>" });

        return interaction.reply({ embeds: [embed], flags: 64 });
    }
};