@echo off
title Discord Bot Baslatıcı

cd /d "%~dp0"

echo Node.js botu baslatiliyor...
node index.js

echo.
echo Bot processi sonlandi. Bu pencereyi kapatabilirsiniz.
pause