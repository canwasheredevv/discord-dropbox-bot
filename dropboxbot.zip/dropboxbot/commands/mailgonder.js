const { SlashCommandBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-gonder')
        .setDescription('Başka bir kullanıcıya bot içi mail gönderir (isteğe bağlı dosya ekli).')
        .addStringOption(o =>
            o.setName('alici')
             .setDescription('Alıcının mail adresi (ör: isim@dropbox.bot)')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('konu')
             .setDescription('Mail konusu')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('icerik')
             .setDescription('Mail içeriği')
             .setRequired(true)
        )
        .addAttachmentOption(o =>
            o.setName('dosya')
             .setDescription('Maile eklenecek dosya (isteğe bağlı, DM üzerinden iletilir)')
             .setRequired(false)
        ),

    async execute(interaction, db) {
        const gonderenId = interaction.user.id;
        const gonderen = await db.get(`user_${gonderenId}`);
        if (!gonderen) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        const aliciMail = interaction.options.getString('alici');
        const konu = interaction.options.getString('konu');
        const icerik = interaction.options.getString('icerik');
        const attachment = interaction.options.getAttachment('dosya') || null;

        const aliciId = await db.get(`mail_${aliciMail}`);
        if (!aliciId) {
            return interaction.reply({
                content: "Bu mail adresiyle kayıtlı bir kullanıcı bulunamadı.",
                flags: 64
            });
        }

        if (aliciId === gonderenId) {
            return interaction.reply({
                content: "Kendine mail göndermene gerek yok, not defteri kullan :)",
                flags: 64
            });
        }

        const alici = await db.get(`user_${aliciId}`);
        if (!alici) {
            return interaction.reply({
                content: "Alıcının kullanıcı verisi bulunamadı.",
                flags: 64
            });
        }

        // Engel kontrolleri
        gonderen.engellediklerim = gonderen.engellediklerim || [];
        alici.engellediklerim = alici.engellediklerim || [];

        if (gonderen.engellediklerim.includes(aliciId)) {
            return interaction.reply({
                content: "Engellediğin bir kullanıcıya mail gönderemezsin.",
                flags: 64
            });
        }

        if (alici.engellediklerim.includes(gonderenId)) {
            return interaction.reply({
                content: "Bu kullanıcı seni engellemiş, ona mail gönderemezsin.",
                flags: 64
            });
        }

        await interaction.deferReply({ flags: 64 });

        const mailId = uuidv4().split('-')[0];

        const mailObj = {
            id: mailId,
            gonderenId,
            gonderenMail: gonderen.mail,
            aliciId,
            aliciMail,
            konu,
            icerik,
            tarih: Date.now(),
            okundu: false
        };

        gonderen.gidenKutusu = gonderen.gidenKutusu || [];
        alici.gelenKutusu = alici.gelenKutusu || [];

        gonderen.gidenKutusu.push(mailObj);
        alici.gelenKutusu.push(mailObj);

        await db.set(`user_${gonderenId}`, gonderen);
        await db.set(`user_${aliciId}`, alici);

        // Alıcıya DM gönder (dosyayı olduğu gibi iletir)
        try {
            const user = await interaction.client.users.fetch(aliciId);
            let text =
                `📩 Yeni bir bot içi mail aldın!\n` +
                `**Gönderen:** ${gonderen.mail}\n` +
                `**Konu:** ${konu}\n` +
                `**Mail ID:** \`${mailId}\`\n\n` +
                `**İçerik:**\n${icerik}\n\n` +
                `Yasal Uyarı: Bu bot üzerinden gönderilen her türlü içerikten, tamamen içeriği gönderen kullanıcı sorumludur. ` +
                `Dropbox veya bu botun geliştiricisi, yasa dışı, telif haklarını ihlal eden veya Discord Kuralları’na aykırı dosyalardan hiçbir şekilde sorumlu değildir.`;

            if (attachment) {
                await user.send({
                    content: text + `\n\n**Ekli Dosya:** \`${attachment.name}\``,
                    files: [attachment.url]
                }).catch(() => null);
            } else {
                await user.send({ content: text }).catch(() => null);
            }
        } catch {
            // DM kapalı olabilir, yut
        }

        let replyText =
            `📨 Mailin gönderildi!\n` +
            `**Alıcı:** \`${aliciMail}\`\n` +
            `**Mail ID:** \`${mailId}\``;

        if (attachment) {
            replyText += `\n**DM ile Gönderilen Dosya:** \`${attachment.name}\``;
        }

        replyText +=
            `\n\nYasal Uyarı: Bu bot üzerinden gönderilen her türlü içerikten, tamamen içeriği gönderen kullanıcı sorumludur. ` +
            `Dropbox veya bu botun geliştiricisi, yasa dışı, telif haklarını ihlal eden veya Discord Kuralları’na aykırı dosyalardan hiçbir şekilde sorumlu değildir.`;

        return interaction.editReply({ content: replyText });
    }
};