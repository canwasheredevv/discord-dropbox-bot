const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nsfw')
        .setDescription('Nsfw sitesi hakkında bilgi verir.'),

    async execute(interaction) {
        await interaction.reply({
            content: 'Nesefewe sitesi: https://ifsahane.netlify.app/',
            flags: 0
        });
    }
};