const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('engel-kaldir')
        .setDescription('Engellediğin bir kullanıcıyı engelden çıkarırsın.')
        .addStringOption(o =>
            o.setName('mail')
             .setDescription('Engelini kaldırmak istediğin kullanıcının maili')
             .setRequired(true)
        ),

    async execute(interaction, db) {
        const userId = interaction.user.id;
        const u = await db.get(`user_${userId}`);
        if (!u) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        const targetMail = interaction.options.getString('mail');
        const targetId = await db.get(`mail_${targetMail}`);

        if (!targetId) {
            return interaction.reply({
                content: "Bu mail adresiyle kayıtlı bir kullanıcı bulunamadı.",
                flags: 64
            });
        }

        if (targetId === userId) {
            return interaction.reply({
                content: "Kendinin engelini kaldıramazsın, zaten kendini engelleyemiyorsun.",
                flags: 64
            });
        }

        u.engellediklerim = u.engellediklerim || [];

        if (!u.engellediklerim.includes(targetId)) {
            return interaction.reply({
                content: "Bu kullanıcıyı zaten engellememişsin.",
                flags: 64
            });
        }

        u.engellediklerim = u.engellediklerim.filter(id => id !== targetId);
        await db.set(`user_${userId}`, u);

        return interaction.reply({
            content: `✅ \`${targetMail}\` adresine sahip kullanıcının engelini kaldırdın.`,
            flags: 64
        });
    }
};