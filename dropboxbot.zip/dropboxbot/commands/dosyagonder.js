const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dosya-gonder')
        .setDescription('Başka bir kullanıcıya dosya gönderir.')
        .addStringOption(o => o.setName('kod').setDescription('Dosya kodu').setRequired(true))
        .addStringOption(o => o.setName('alici_mail').setDescription('Alıcının bot maili').setRequired(true)),
    async execute(interaction, db) {
        const kod = interaction.options.getString('kod').toUpperCase();
        const mail = interaction.options.getString('alici_mail').toLowerCase();
        
        const gonderen = await db.get(`user_${interaction.user.id}`);
        const aliciId = await db.get(`mail_${mail}`);

        if (!aliciId) return interaction.reply({ content: "Böyle bir mail adresi sistemde yok!", ephemeral: true });
        
        const dosya = gonderen.dosyalar.find(d => d.id === kod);
        if (!dosya) return interaction.reply({ content: "Hatalı veya size ait olmayan dosya kodu!", ephemeral: true });

        const aliciUser = await interaction.client.users.fetch(aliciId);
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`onay_${kod}_${interaction.user.id}`).setLabel('Dosyayı Kabul Et').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('red').setLabel('Reddet').setStyle(ButtonStyle.Danger)
        );

        // Alıcıya mesaj gönder
        await aliciUser.send({
            content: `📬 **${gonderen.isim}** sana bir dosya gönderdi!\n**Dosya Adı:** ${dosya.ad}\n**Boyut:** ${dosya.boyut}\nOnaylıyor musun?`,
            components: [row]
        }).catch(() => {
            return interaction.reply({ content: "Alıcının DM' kutusu kapalı olduğu için gönderilemedi!", ephemeral: true });
        });

        // Geçmişe Kaydet
        const transferBilgi = {
            tarih: new Date().toLocaleDateString('tr-TR'),
            alici: mail,
            dosyaAd: dosya.ad
        };
        await db.push(`user_${interaction.user.id}.gecmis`, transferBilgi);

        await interaction.reply({ content: `✅ Dosya transfer isteği **${mail}** adresine iletildi.`, ephemeral: true });
    }
};
