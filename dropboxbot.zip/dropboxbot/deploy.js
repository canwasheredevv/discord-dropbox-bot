const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const config = require('./config.js');

// UYGULAMA ID'SINI BURAYA YAZ
const APPLICATION_ID = 'id';

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs
  .readdirSync(commandsPath)
  .filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);

  if (!command.data) continue;

  const json = command.data.toJSON();
  if (command.integration_types) json.integration_types = command.integration_types;
  if (command.contexts) json.contexts = command.contexts;

  commands.push(json);
}

const rest = new REST({ version: '10' }).setToken(config.token);

(async () => {
  try {
    console.log(`Toplam ${commands.length} komut bulundu. Discord'a yükleniyor...`);

    await rest.put(
      Routes.applicationCommands(APPLICATION_ID),
      { body: commands },
    );

    console.log('Global komutlar başarıyla yüklendi.');
  } catch (error) {
    console.error('Komut yüklenirken hata oluştu:', error);
  }
})();