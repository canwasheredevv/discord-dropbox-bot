const { SlashCommandBuilder } = require('discord.js');
const config = require('../config.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('hak-ver')
        .setDescription('Hak ekler (Admin).')
        .addUserOption(o => o.setName('kisi').setDescription('Kişi').setRequired(true))
        .addIntegerOption(o => o.setName('miktar').setDescription('Miktar').setRequired(true)),
    async execute(interaction, db) {
        if (interaction.user.id !== config.sahipID) return interaction.reply("Yetkin yok.");
        const hedef = interaction.options.getUser('kisi');
        const miktar = interaction.options.getInteger('miktar');
        await db.add(`user_${hedef.id}.hak`, miktar);
        await interaction.reply(`${hedef.username} kullanıcısına ${miktar} hak verildi.`);
    }
};
