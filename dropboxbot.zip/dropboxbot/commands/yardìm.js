const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('yardim')
        .setDescription('Botun tüm komutlarını kategori seçerek görüntülersin.'),

    async execute(interaction) {
        const client = interaction.client;
        const user = interaction.user;

        const pages = {
            hesap: new EmbedBuilder()
                .setTitle('👤 Hesap & Profil & Takip & Engel')
                .setColor(config.embedRenk || 0x34a853)
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription(
                    '**Hesap Yönetimi**\n' +
                    '• `/hesap-olustur` → Bot içinde Dropbox hesabı benzeri profil oluşturur, mail verir.\n' +
                    '• `/profil` → İsim, mail, dosya istatistikleri, takip ve mail kutunu gösterir.\n' +
                    '• `/ayarlar` → Biyografi, mail/tarih gizliliği vb. profil ayarlarını yönetir.\n' +
                    '• `/isim-degistir` → Sistemdeki adını günceller.\n' +
                    '• `/sifirla` → Hesabını tamamen siler (geri alınamaz).\n\n' +
                    '**Takip Sistemi**\n' +
                    '• `/takipet mail@dropbox.bot` → Mailini yazdığın kullanıcıyı takip edersin.\n' +
                    '• `/takipcik mail@dropbox.bot` → O kullanıcıyı takipten çıkarsın.\n' +
                    'Takip bilgileri profilinde görünür.\n\n' +
                    '**Engel Sistemi**\n' +
                    '• `/engelle mail@dropbox.bot` → O kullanıcıyla arandaki mail/dosya trafiğini keser.\n' +
                    '• `/engel-kaldir mail@dropbox.bot` → Engelini kaldırır.\n' +
                    '• `/engel-liste` → Engellediğin kullanıcıların listesini gösterir.'
                )
                .setFooter({ text: 'Kategori: Hesap & Profil', iconURL: user.displayAvatarURL() })
                .setTimestamp(),

            dosya: new EmbedBuilder()
                .setTitle('📥 Dosya İşlemleri (Dropbox)')
                .setColor(config.embedRenk || 0x34a853)
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription(
                    '**Dosya Yükleme & Yönetim**\n' +
                    '• `/dosya-yukle` → Dosyayı botun Dropbox sürücüsüne yükler. Dosya 3 saat sonra otomatik silinir.\n' +
                    '  - Yükleme sonrası sana bir kod ve paylaşılabilir link verir.\n' +
                    '• `/dosyalarim` → Kayıtlı dosyalarını listeler (kod, isim, süre vb.).\n' +
                    '• `/dosya-bilgi` → Belirli bir dosyanın detaylarını gösterir (kod ile).\n' +
                    '• `/dosya-sil` → Kodunu belirttiğin dosyayı siler.\n' +
                    '• `/dosya-ara` → Dosyaların arasında isimle arama yapar.\n\n' +
                    '**Haklar & Limitler**\n' +
                    '• `/hakkim` → Kalan yükleme hakkını gösterir.\n' +
                    '• `/gunluk-hak` → Her 24 saatte bir +1 yükleme hakkı verir.\n' +
                    '3 saat sonra dosyalar hem botta kayıtlarından hem de Dropbox hesabından silinir.'
                )
                .setFooter({ text: 'Kategori: Dosya İşlemleri', iconURL: user.displayAvatarURL() })
                .setTimestamp(),

            mail: new EmbedBuilder()
                .setTitle('📨 Bot İçi Mail / Mesajlaşma')
                .setColor(config.embedRenk || 0x34a853)
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription(
                    '**Mail Sistemi Temeli**\n' +
                    '• Kayıt olurken sana otomatik bir mail verilir: `kullanici@dropbox.bot`\n' +
                    '• Bu mail ile diğer kullanıcılar sana bot içi mail gönderebilir.\n\n' +
                    '**Komutlar**\n' +
                    '• `/mail-gonder` → Başka bir kullanıcının mail adresine metin maili gönderir.\n' +
                    '  - İsteğe bağlı: `dosya` ekleyerek alıcıya DM üzerinden dosya da gönderebilirsin.\n' +
                    '• `/mail-gelen` → Gelen kutundaki mailleri listeler (sana gelenler).\n' +
                    '• `/mail-giden` → Gönderdiğin mailleri listeler.\n' +
                    '• `/mail-oku id:MAIL_ID` → Belirli bir mailin detayını (konu, içerik, tarih) gösterir.\n' +
                    '• `/mail-sil id:MAIL_ID` → Gelen ve giden kutundan bu ID\'li maili siler.\n' +
                    '• `/mail-sorgula` → Bir mail adresinin hangi kullanıcıya ait olduğunu bulur.\n\n' +
                    '**Engel Etkisi**\n' +
                    '• Eğer bir kullanıcıyı `/engelle` komutuyla engellersen:\n' +
                    '  - Sen ona mail gönderemezsin.\n' +
                    '  - O da sana mail gönderemez.'
                )
                .setFooter({ text: 'Kategori: Mail Sistemi', iconURL: user.displayAvatarURL() })
                .setTimestamp(),

            genel: new EmbedBuilder()
                .setTitle('📊 Genel Komutlar & İpuçları')
                .setColor(config.embedRenk || 0x34a853)
                .setThumbnail(client.user.displayAvatarURL())
                .setDescription(
                    '**Genel Komutlar**\n' +
                    '• `/istatistik` → Botun sistem ve kullanım istatistiklerini gösterir (uptime, RAM, kullanıcı sayısı vb.).\n' +
                    '• `/ping` → Botun gecikme süresini ölçer.\n' +
                    '• `/yardim` → Bu menüyü açar.\n\n' +
                    '**Hızlı Başlangıç Rehberi**\n' +
                    '1. `/hesap-olustur` → Kayıt ol ve mail adresini al.\n' +
                    '2. `/profil` → Hesabını, mail adresini, takipçi sayını ve dosya sayını incele.\n' +
                    '3. `/dosya-yukle` → Dosyalarını botun Dropbox sürücüsüne yükle.\n' +
                    '4. `/mail-gonder` → Arkadaşlarının mail adresine metin ve isteğe bağlı dosya gönder.\n' +
                    '5. `/engelle` ve `/engel-liste` → İstemediğin kullanıcıları engelle.\n' +
                    '6. `/ayarlar` ile profil görünümünü ve gizliliğini düzenle.\n\n' +
                    '**İpucu:**\n' +
                    '• Tüm sistem bot içi çalışır; gerçek Dropbox hesaplarına doğrudan bağlanmaz.\n' +
                    '• Dosyalar 3 saat sonra otomatik silinir, bu yüzden uzun süreli arşiv için kendi hesabını kullanman önerilir.'
                )
                .setFooter({ text: 'Kategori: Genel & İpuçları', iconURL: user.displayAvatarURL() })
                .setTimestamp()
        };

        let currentKey = 'hesap';

        const select = new StringSelectMenuBuilder()
            .setCustomId('yardim_select')
            .setPlaceholder('Bir kategori seç...')
            .addOptions(
                {
                    label: '👤 Hesap / Profil / Takip / Engel',
                    description: 'Hesap yönetimi, profil, takip ve engelleme.',
                    value: 'hesap'
                },
                {
                    label: '📥 Dosya / Dropbox',
                    description: 'Dosya yükleme, listeleme, silme ve haklar.',
                    value: 'dosya'
                },
                {
                    label: '📨 Mail Sistemi',
                    description: 'Bot içi mail ve mesajlaşma.',
                    value: 'mail'
                },
                {
                    label: '📊 Genel & İpuçları',
                    description: 'Genel komutlar ve hızlı başlangıç rehberi.',
                    value: 'genel'
                }
            );

        const selectRow = new ActionRowBuilder().addComponents(select);

        const ownerRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Bot Sahibi')
                .setStyle(ButtonStyle.Link)
                .setURL(`https://discord.com/users/${config.sahipID}`)
        );

        const reply = await interaction.reply({
            embeds: [pages[currentKey]],
            components: [selectRow, ownerRow],
            flags: 0
        });

        const collector = reply.createMessageComponentCollector({
            time: 1000 * 60 * 3
        });

        collector.on('collect', async (comp) => {
            if (comp.user.id !== user.id) {
                return comp.reply({
                    content: 'Bu yardım menüsünü sadece komutu kullanan kişi kontrol edebilir.',
                    flags: 64
                });
            }

            if (comp.customId === 'yardim_select') {
                const value = comp.values[0];
                if (!pages[value]) return;

                currentKey = value;

                await comp.update({
                    embeds: [pages[currentKey]],
                    components: [selectRow, ownerRow]
                });
            }
        });

        collector.on('end', async () => {
            try {
                const disabledSelect = StringSelectMenuBuilder.from(select).setDisabled(true);
                const disabledRow = new ActionRowBuilder().addComponents(disabledSelect);

                await reply.edit({
                    components: [disabledRow, ownerRow]
                });
            } catch {
                // görmezden gel
            }
        });
    }
};