const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dosya-sil')
        .setDescription('Sürücünüzden bir dosyayı siler.')
        .addStringOption(o => o.setName('kod').setDescription('Silinecek dosya kodu').setRequired(true)),
    async execute(interaction, db) {
        const kod = interaction.options.getString('kod');
        const data = await db.get(`user_${interaction.user.id}`);
        
        const dosyaIndex = data.dosyalar.findIndex(d => d.id === kod);
        if (dosyaIndex === -1) return interaction.reply("Böyle bir dosya bulunamadı.");

        const dosya = data.dosyalar[dosyaIndex];
        
        // Google Drive'dan da siler (Opsiyonel)
        try { await drive.files.delete({ fileId: dosya.driveId }); } catch (e) {}

        data.dosyalar.splice(dosyaIndex, 1);
        await db.set(`user_${interaction.user.id}.dosyalar`, data.dosyalar);
        
        await interaction.reply(`🗑️ \`${dosya.ad}\` dosyası sürücünüzden silindi.`);
    }
};
