# 📁 Google Drive Discord Bot (v14) // by: katliamcxn.

Bu bot, kullanıcıların Discord üzerinden kendi "sanal sürücülerini" oluşturmasına, Google Drive'a dosya yüklemesine ve birbirlerine bot içi mail adresleri üzerinden dosya göndermesine olanak tanır. (Çalıştığından tam bilgimiz yok %80 ihtimalle çalışıyor! )

## 🚀 Kurulum Rehberi

### 1. Kütüphaneleri Yükleme
Proje klasörüne gidin ve terminale (veya CMD) aşağıdaki komutu yapıştırın. Bu komut tüm gerekli paketleri (`discord.js`, `google-api`, `database` ve `file-downloader`) tek seferde kuracaktır:

npm install discord.js
npm install quick.db better-sqlite3
npm install googleapis
npm install axios
npm install dotenv
