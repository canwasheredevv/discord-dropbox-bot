const {
    SlashCommandBuilder,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');
const { createCanvas } = require('@napi-rs/canvas');
const { randomUUID } = require('node:crypto');

const SCALE = 1.35;
const px = (value) => Math.round(value * SCALE);
const FONT_STACK = '"Segoe UI","Segoe UI Emoji","Noto Color Emoji","Apple Color Emoji","Noto Sans","Arial Unicode MS",sans-serif';

const CANVAS_WIDTH = px(760);
const BASE_CANVAS_HEIGHT = px(980);
const MIN_CANVAS_HEIGHT = BASE_CANVAS_HEIGHT;
const MAX_CANVAS_HEIGHT = px(2100);
const CARD_X = px(44);
const CARD_Y = px(40);
const CARD_WIDTH = CANVAS_WIDTH - CARD_X * 2;
const CARD_RADIUS = px(34);
const CARD_INNER_PADDING = px(24);
const CONTENT_SIDE_PADDING = px(30);
const MEDIA_HEIGHT = px(360);
const FIELD_LABEL_GAP = px(34);
const FIELD_LINE_HEIGHT = px(36);
const FIELD_BOTTOM_GAP = px(10);
const TITLE_LINE_HEIGHT = px(56);
const TITLE_BOTTOM_GAP = px(20);
const FOOTER_RESERVED_HEIGHT = px(82);
const MAX_KONU_LENGTH = 600;
const MAX_ICERIK_LENGTH = 4000;
const MAX_KONU_GRAPHEME_COUNT = 600;
const MAX_ICERIK_GRAPHEME_COUNT = 3200;
const MAX_GONDEREN_GRAPHEME_COUNT = 220;
const MAX_GRAPHEME_RUN = 120;
const MAX_TEXT_MEASURE_CALLS = 25000;
const CONTROL_CHAR_REGEX = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
const UNSAFE_BIDI_REGEX = /[\u202A-\u202E\u2066-\u2069]/g;
const UNSAFE_ZERO_WIDTH_REGEX = /[\u200B\u200E\u200F\uFEFF]/g;
const graphemeSegmenter = typeof Intl !== 'undefined' && Intl.Segmenter
    ? new Intl.Segmenter('tr', { granularity: 'grapheme' })
    : null;

function roundedRectPath(ctx, x, y, width, height, radius) {
    const r = Math.max(0, Math.min(radius, width / 2, height / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
}

function splitGraphemes(text) {
    if (!text) return [];
    if (graphemeSegmenter) {
        return [...graphemeSegmenter.segment(text)].map((s) => s.segment);
    }
    return Array.from(text);
}

function clampByGraphemeCount(text, maxGraphemes) {
    const graphemes = splitGraphemes(text);
    if (graphemes.length <= maxGraphemes) {
        return text;
    }
    return graphemes.slice(0, maxGraphemes).join('').trimEnd();
}

function normalizeInputText(value) {
    if (typeof value !== 'string') return '';

    return value
        .normalize('NFKC')
        .replace(CONTROL_CHAR_REGEX, ' ')
        .replace(UNSAFE_BIDI_REGEX, '')
        .replace(UNSAFE_ZERO_WIDTH_REGEX, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function hasExcessiveGraphemeRun(text, maxRun) {
    const graphemes = splitGraphemes(text);
    let previous = '';
    let run = 0;

    for (const g of graphemes) {
        if (g === previous) {
            run += 1;
            if (run > maxRun) {
                return true;
            }
        } else {
            previous = g;
            run = 1;
        }
    }

    return false;
}

function createMeasureState(ctx) {
    return {
        ctx,
        cache: new Map(),
        count: 0
    };
}

function measureTextWidth(state, text) {
    const key = `${state.ctx.font}__${text}`;
    const cached = state.cache.get(key);
    if (cached !== undefined) {
        return cached;
    }

    state.count += 1;
    if (state.count > MAX_TEXT_MEASURE_CALLS) {
        const error = new Error('MAIL_TEXT_COMPLEXITY_LIMIT');
        error.code = 'MAIL_TEXT_COMPLEXITY_LIMIT';
        throw error;
    }

    const width = state.ctx.measureText(text).width;
    state.cache.set(key, width);
    return width;
}

function validateInputText(label, value, maxChars, maxGraphemes) {
    const normalized = normalizeInputText(value);
    if (!normalized) {
        return { ok: false, error: `${label} boş veya geçersiz karakterlerden oluşuyor.` };
    }

    if (normalized.length > maxChars) {
        return { ok: false, error: `${label} en fazla ${maxChars} karakter olabilir.` };
    }

    const graphemeCount = splitGraphemes(normalized).length;
    if (graphemeCount > maxGraphemes) {
        return { ok: false, error: `${label} en fazla ${maxGraphemes} karakter/grafem olabilir.` };
    }

    if (hasExcessiveGraphemeRun(normalized, MAX_GRAPHEME_RUN)) {
        return {
            ok: false,
            error: `${label} içinde aynı karakter çok fazla tekrar ediyor. Lütfen spam/abuse içeriğini azalt.`
        };
    }

    return { ok: true, value: normalized, graphemeCount };
}

function sanitizeText(value, maxLength = 500) {
    const cleaned = normalizeInputText(value);

    if (!cleaned) return '-';
    return clampByGraphemeCount(cleaned, maxLength);
}

function trimToWidthWithEllipsis(state, text, maxWidth) {
    const ellipsis = '...';
    const normalizedText = text.trimEnd();

    if (measureTextWidth(state, normalizedText) <= maxWidth) {
        return normalizedText;
    }

    const graphemes = splitGraphemes(normalizedText);
    let low = 0;
    let high = graphemes.length;
    let best = 0;

    while (low <= high) {
        const mid = (low + high) >> 1;
        const candidate = graphemes.slice(0, mid).join('').trimEnd();
        const candidateWithEllipsis = candidate ? candidate + ellipsis : ellipsis;

        if (measureTextWidth(state, candidateWithEllipsis) <= maxWidth) {
            best = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    const trimmed = graphemes.slice(0, best).join('').trimEnd();
    return trimmed ? trimmed + ellipsis : ellipsis;
}

function splitLongWord(state, word, maxWidth) {
    const chunks = [];
    const graphemes = splitGraphemes(word);
    let start = 0;

    while (start < graphemes.length) {
        let low = 1;
        let high = graphemes.length - start;
        let best = 0;

        while (low <= high) {
            const mid = (low + high) >> 1;
            const candidate = graphemes.slice(start, start + mid).join('');

            if (measureTextWidth(state, candidate) <= maxWidth) {
                best = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        const takeCount = best > 0 ? best : 1;
        chunks.push(graphemes.slice(start, start + takeCount).join(''));
        start += takeCount;
    }

    return chunks;
}

function wrapText(state, value, maxWidth, maxLines) {
    const text = sanitizeText(value, 8000);
    const words = text.split(/\s+/).filter(Boolean);

    if (words.length === 0) {
        return ['-'];
    }

    const lines = [];
    let currentLine = '';
    let overflow = false;

    for (const word of words) {
        const pieces = measureTextWidth(state, word) > maxWidth
            ? splitLongWord(state, word, maxWidth)
            : [word];

        for (const piece of pieces) {
            const candidate = currentLine ? `${currentLine} ${piece}` : piece;

            if (!currentLine || measureTextWidth(state, candidate) <= maxWidth) {
                currentLine = candidate;
                continue;
            }

            lines.push(currentLine);
            currentLine = piece;

            if (lines.length >= maxLines) {
                overflow = true;
                break;
            }
        }

        if (overflow) break;
    }

    if (!overflow && currentLine) {
        lines.push(currentLine);
    } else if (overflow && currentLine && lines.length < maxLines) {
        lines.push(currentLine);
    }

    const output = lines.slice(0, maxLines);

    if (overflow && output.length > 0) {
        output[output.length - 1] = trimToWidthWithEllipsis(
            state,
            output[output.length - 1],
            maxWidth
        );
    }

    return output.length > 0 ? output : ['-'];
}

function wrapTextUnlimited(state, value, maxWidth) {
    const text = sanitizeText(value, 8000);
    const words = text.split(/\s+/).filter(Boolean);

    if (words.length === 0) {
        return ['-'];
    }

    const lines = [];
    let currentLine = '';

    for (const word of words) {
        const pieces = measureTextWidth(state, word) > maxWidth
            ? splitLongWord(state, word, maxWidth)
            : [word];

        for (const piece of pieces) {
            const candidate = currentLine ? `${currentLine} ${piece}` : piece;

            if (!currentLine || measureTextWidth(state, candidate) <= maxWidth) {
                currentLine = candidate;
            } else {
                lines.push(currentLine);
                currentLine = piece;
            }
        }
    }

    if (currentLine) {
        lines.push(currentLine);
    }

    return lines.length > 0 ? lines : ['-'];
}

function drawEnvelope(ctx, x, y, width, height) {
    const bodyGradient = ctx.createLinearGradient(x, y, x + width, y + height);
    bodyGradient.addColorStop(0, '#4F86FF');
    bodyGradient.addColorStop(1, '#3E6FDE');

    roundedRectPath(ctx, x, y, width, height, 10);
    ctx.fillStyle = bodyGradient;
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + width / 2, y + height * 0.56);
    ctx.lineTo(x + width, y);
    ctx.closePath();
    ctx.fillStyle = '#5F90F8';
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x, y + height);
    ctx.lineTo(x + width / 2, y + height * 0.56);
    ctx.lineTo(x + width, y + height);
    ctx.closePath();
    ctx.fillStyle = '#4A7EE8';
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + width * 0.42, y + height * 0.56);
    ctx.lineTo(x, y + height);
    ctx.closePath();
    ctx.fillStyle = '#3F73DF';
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x + width, y);
    ctx.lineTo(x + width * 0.58, y + height * 0.56);
    ctx.lineTo(x + width, y + height);
    ctx.closePath();
    ctx.fillStyle = '#4579E4';
    ctx.fill();
}

function getFieldHeight(lineCount) {
    return FIELD_LABEL_GAP + lineCount * FIELD_LINE_HEIGHT + FIELD_BOTTOM_GAP;
}

function drawFieldLines(ctx, { label, lines, x, y }) {
    ctx.fillStyle = '#8A90A0';
    ctx.font = `600 ${px(22)}px ${FONT_STACK}`;
    ctx.fillText(label, x, y);

    const textY = y + FIELD_LABEL_GAP;
    ctx.fillStyle = '#E9ECF5';
    ctx.font = `500 ${px(30)}px ${FONT_STACK}`;
    lines.forEach((line, index) => {
        ctx.fillText(line, x, textY + index * FIELD_LINE_HEIGHT);
    });

    return textY + lines.length * FIELD_LINE_HEIGHT + FIELD_BOTTOM_GAP;
}

function buildMailCanvasLayout({ gonderenMail, konu, icerik, mailId }) {
    const safeSender = sanitizeText(gonderenMail, MAX_GONDEREN_GRAPHEME_COUNT);
    const safeSubject = sanitizeText(konu, MAX_KONU_GRAPHEME_COUNT);
    const safePreview = sanitizeText(icerik, MAX_ICERIK_GRAPHEME_COUNT);
    const safeMailId = sanitizeText(mailId, 40);

    const measuringCanvas = createCanvas(CANVAS_WIDTH, MIN_CANVAS_HEIGHT);
    const measureCtx = measuringCanvas.getContext('2d');
    const measureState = createMeasureState(measureCtx);

    const contentWidth = CARD_WIDTH - CONTENT_SIDE_PADDING * 2;
    const mediaY = CARD_Y + CARD_INNER_PADDING;

    measureCtx.font = `700 ${px(52)}px ${FONT_STACK}`;
    const titleLines = wrapText(measureState, 'Yeni mail!', contentWidth, 2);

    measureCtx.font = `500 ${px(30)}px ${FONT_STACK}`;
    const senderLines = wrapTextUnlimited(measureState, safeSender, contentWidth);
    const subjectLines = wrapTextUnlimited(measureState, safeSubject, contentWidth);
    const previewLines = wrapTextUnlimited(measureState, safePreview, contentWidth);

    let cursorY = mediaY + MEDIA_HEIGHT + px(112);
    cursorY += titleLines.length * TITLE_LINE_HEIGHT + TITLE_BOTTOM_GAP;
    cursorY += getFieldHeight(senderLines.length);
    cursorY += getFieldHeight(subjectLines.length);
    cursorY += getFieldHeight(previewLines.length);

    const requiredCardBottom = cursorY + FOOTER_RESERVED_HEIGHT;
    const requiredCanvasHeight = requiredCardBottom + CARD_Y;

    if (requiredCanvasHeight > MAX_CANVAS_HEIGHT) {
        const error = new Error('MAIL_CANVAS_LIMIT_EXCEEDED');
        error.code = 'MAIL_CANVAS_LIMIT_EXCEEDED';
        error.meta = {
            requiredHeight: requiredCanvasHeight,
            maxHeight: MAX_CANVAS_HEIGHT,
            previewLines: previewLines.length,
            subjectLines: subjectLines.length
        };
        throw error;
    }

    const canvasHeight = Math.max(MIN_CANVAS_HEIGHT, requiredCanvasHeight);
    const cardHeight = canvasHeight - CARD_Y * 2;

    return {
        safeSender,
        safeSubject,
        safePreview,
        safeMailId,
        canvasHeight,
        cardHeight,
        contentWidth,
        titleLines,
        senderLines,
        subjectLines,
        previewLines
    };
}

function createMailNotificationAttachment(layout) {
    const {
        safeMailId,
        canvasHeight,
        cardHeight,
        contentWidth,
        titleLines,
        senderLines,
        subjectLines,
        previewLines
    } = layout;

    const canvas = createCanvas(CANVAS_WIDTH, canvasHeight);
    const ctx = canvas.getContext('2d');
    const renderMeasureState = createMeasureState(ctx);

    const pageGradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
    pageGradient.addColorStop(0, '#05070E');
    pageGradient.addColorStop(1, '#03040A');
    ctx.fillStyle = pageGradient;
    ctx.fillRect(0, 0, CANVAS_WIDTH, canvasHeight);

    const ambientGlow = ctx.createRadialGradient(CANVAS_WIDTH * 0.55, px(120), px(50), CANVAS_WIDTH * 0.55, px(120), px(500));
    ambientGlow.addColorStop(0, 'rgba(62, 108, 228, 0.18)');
    ambientGlow.addColorStop(1, 'rgba(62, 108, 228, 0)');
    ctx.fillStyle = ambientGlow;
    ctx.fillRect(0, 0, CANVAS_WIDTH, canvasHeight);

    roundedRectPath(ctx, CARD_X, CARD_Y, CARD_WIDTH, cardHeight, CARD_RADIUS);
    ctx.fillStyle = '#1D2027';
    ctx.fill();

    const mediaX = CARD_X + CARD_INNER_PADDING;
    const mediaY = CARD_Y + CARD_INNER_PADDING;
    const mediaWidth = CARD_WIDTH - CARD_INNER_PADDING * 2;

    roundedRectPath(ctx, mediaX, mediaY, mediaWidth, MEDIA_HEIGHT, px(22));
    const mediaGradient = ctx.createLinearGradient(mediaX, mediaY, mediaX + mediaWidth, mediaY + MEDIA_HEIGHT);
    mediaGradient.addColorStop(0, '#2C2E35');
    mediaGradient.addColorStop(1, '#23252B');
    ctx.fillStyle = mediaGradient;
    ctx.fill();

    const mediaShade = ctx.createLinearGradient(mediaX, mediaY, mediaX, mediaY + MEDIA_HEIGHT);
    mediaShade.addColorStop(0, 'rgba(255, 255, 255, 0.04)');
    mediaShade.addColorStop(1, 'rgba(0, 0, 0, 0.16)');
    ctx.fillStyle = mediaShade;
    ctx.fillRect(mediaX, mediaY, mediaWidth, MEDIA_HEIGHT);

    const envelopeWidth = Math.floor(mediaWidth * 0.7);
    const envelopeHeight = px(162);
    const envelopeX = mediaX + Math.floor((mediaWidth - envelopeWidth) / 2);
    const envelopeY = mediaY + MEDIA_HEIGHT - px(148);
    drawEnvelope(ctx, envelopeX, envelopeY, envelopeWidth, envelopeHeight);

    ctx.fillStyle = '#4B84FF';
    ctx.font = `700 ${px(40)}px ${FONT_STACK}`;
    ctx.fillText('Mail Kutusu', CARD_X + CONTENT_SIDE_PADDING, mediaY + MEDIA_HEIGHT + px(58));

    const contentX = CARD_X + CONTENT_SIDE_PADDING;
    let cursorY = mediaY + MEDIA_HEIGHT + px(112);

    ctx.fillStyle = '#F0F3FA';
    ctx.font = `700 ${px(52)}px ${FONT_STACK}`;
    titleLines.forEach((line, index) => {
        ctx.fillText(line, contentX, cursorY + index * TITLE_LINE_HEIGHT);
    });
    cursorY += titleLines.length * TITLE_LINE_HEIGHT + TITLE_BOTTOM_GAP;

    cursorY = drawFieldLines(ctx, {
        label: 'Gönderen',
        lines: senderLines,
        x: contentX,
        y: cursorY
    });

    cursorY = drawFieldLines(ctx, {
        label: 'Konu',
        lines: subjectLines,
        x: contentX,
        y: cursorY
    });

    cursorY = drawFieldLines(ctx, {
        label: 'Önizleme',
        lines: previewLines,
        x: contentX,
        y: cursorY
    });

    const cardBottom = CARD_Y + cardHeight;
    ctx.font = `600 ${px(24)}px ${FONT_STACK}`;
    const pillText = trimToWidthWithEllipsis(renderMeasureState, `/mail-oku id:${safeMailId}`, contentWidth - px(32));
    const pillWidth = Math.min(contentWidth, Math.ceil(measureTextWidth(renderMeasureState, pillText) + px(34)));
    const pillHeight = px(46);
    const pillX = contentX;
    const pillY = cardBottom - px(70);

    roundedRectPath(ctx, pillX, pillY, pillWidth, pillHeight, px(20));
    ctx.fillStyle = '#343741';
    ctx.fill();

    ctx.fillStyle = '#D6DBE8';
    ctx.fillText(pillText, pillX + px(17), pillY + px(32));

    const imageBuffer = canvas.toBuffer('image/png');
    return new AttachmentBuilder(imageBuffer, { name: `mail-bildirim-${safeMailId}.png` });
}

function buildReadMailCommand(mailId) {
    const safeMailId = sanitizeText(mailId, 40).replace(/[^a-zA-Z0-9]/g, '').slice(0, 40);
    return `/mail-oku id:${safeMailId || 'hata'}`;
}

function buildReadMailButtonRow(targetUserId, mailId) {
    const safeMailId = sanitizeText(mailId, 40).replace(/[^a-zA-Z0-9]/g, '').slice(0, 40) || 'hata';
    const customId = `mailcopy_${targetUserId}_${safeMailId}`;

    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(customId)
            .setLabel('Mail Oku Komutunu Kopyala')
            .setStyle(ButtonStyle.Primary)
    );
}

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-gonder')
        .setDescription('Başka bir kullanıcıya bot içi mail gönderir.')
        .addStringOption(o =>
            o.setName('alici')
             .setDescription('Alıcının mail adresi (örn: isim@dropbox.bot)')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('konu')
             .setDescription('Mail konusu')
               .setMaxLength(MAX_KONU_LENGTH)
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('icerik')
             .setDescription('Mail içeriği')
               .setMaxLength(MAX_ICERIK_LENGTH)
             .setRequired(true)
        ),

    async execute(interaction, db) {
        const gonderenId = interaction.user.id;
        const gonderen = await db.get(`user_${gonderenId}`);
        if (!gonderen) {
            return interaction.reply({ content: "Önce `/hesap-olustur` ile kayıt olmalısın!", flags: 64 });
        }

        const aliciMail = interaction.options.getString('alici');
        const rawKonu = interaction.options.getString('konu');
        const rawIcerik = interaction.options.getString('icerik');

        const konuValidation = validateInputText('Konu', rawKonu, MAX_KONU_LENGTH, MAX_KONU_GRAPHEME_COUNT);
        if (!konuValidation.ok) {
            return interaction.reply({
                content: `❌ ${konuValidation.error}`,
                flags: 64
            });
        }

        const icerikValidation = validateInputText('İçerik', rawIcerik, MAX_ICERIK_LENGTH, MAX_ICERIK_GRAPHEME_COUNT);
        if (!icerikValidation.ok) {
            return interaction.reply({
                content: `❌ ${icerikValidation.error}`,
                flags: 64
            });
        }

        const konu = konuValidation.value;
        const icerik = icerikValidation.value;

        const aliciId = await db.get(`mail_${aliciMail}`);
        if (!aliciId) {
            return interaction.reply({ content: "Bu mail adresiyle kayıtlı bir kullanıcı yok.", flags: 64 });
        }

        const alici = await db.get(`user_${aliciId}`);
        if (!alici) {
            return interaction.reply({ content: "Alıcının kullanıcı verisi bulunamadı.", flags: 64 });
        }

        const mailId = randomUUID().split('-')[0];
        let canvasLayout;
        let canvasAttachment;

        try {
            canvasLayout = buildMailCanvasLayout({
                gonderenMail: gonderen.mail,
                konu,
                icerik,
                mailId
            });

            canvasAttachment = createMailNotificationAttachment(canvasLayout);
        } catch (error) {
            if (error?.code === 'MAIL_CANVAS_LIMIT_EXCEEDED') {
                const requiredHeight = error?.meta?.requiredHeight || 0;
                return interaction.reply({
                    content: `❌ İçerik canvas limitini aşıyor. Gereken yükseklik: ${requiredHeight}px, izin verilen üst sınır: ${MAX_CANVAS_HEIGHT}px. Lütfen konu/içeriği kısaltıp tekrar dene.`,
                    flags: 64
                });
            }

            if (error?.code === 'MAIL_TEXT_COMPLEXITY_LIMIT') {
                return interaction.reply({
                    content: '❌ İçerik çok karmaşık olduğu için güvenlik limiti devreye girdi. Lütfen metni sadeleştirip tekrar dene.',
                    flags: 64
                });
            }

            console.error('Canvas oluşturma hatası:', error);
            canvasLayout = null;
            canvasAttachment = null;
        }

        const mailObj = {
            id: mailId,
            gonderenId,
            gonderenMail: gonderen.mail,
            aliciId,
            aliciMail,
            konu,
            icerik,
            tarih: Date.now(),
            okundu: false
        };

        gonderen.gidenKutusu = gonderen.gidenKutusu || [];
        alici.gelenKutusu = alici.gelenKutusu || [];

        gonderen.gidenKutusu.push(mailObj);
        alici.gelenKutusu.push(mailObj);

        await db.set(`user_${gonderenId}`, gonderen);
        await db.set(`user_${aliciId}`, alici);

        try {
            const user = await interaction.client.users.fetch(aliciId);
            const readMailCommand = buildReadMailCommand(mailId);
            const readMailButtonRow = buildReadMailButtonRow(aliciId, mailId);
            const safeSubjectForFallback = canvasLayout?.safeSubject || sanitizeText(konu, MAX_KONU_GRAPHEME_COUNT);
            const fallbackMessage = [
                '📩 Yeni bir bot içi mail aldın!',
                `**Gönderen:** ${sanitizeText(gonderen.mail, MAX_GONDEREN_GRAPHEME_COUNT)}`,
                `**Konu:** ${safeSubjectForFallback}`,
                `Mail ID: \`${sanitizeText(mailId, 40)}\``,
                `Detay: \`${readMailCommand}\``
            ].join('\n');

            let sent = false;
            if (canvasAttachment) {
                try {
                    await user.send({ files: [canvasAttachment], components: [readMailButtonRow] });
                    sent = true;
                } catch {
                    // Canvas gönderimi başarısızsa metin fallback kullanılır.
                }
            }

            if (!sent) {
                await user.send({ content: fallbackMessage, components: [readMailButtonRow] }).catch(() => null);
            }
        } catch {}

        return interaction.reply({
            content: `📨 Mail gönderildi!\n**Alıcı:** \`${aliciMail}\`\n**Mail ID:** \`${mailId}\``,
            flags: 64
        });
    }
};


const { SlashCommandBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const { Dropbox } = require('dropbox');
const fetch = require('node-fetch');
const axios = require('axios');
const config = require('../config.js');

const dbx = new Dropbox({
    accessToken: config.dropbox.accessToken,
    fetch
});