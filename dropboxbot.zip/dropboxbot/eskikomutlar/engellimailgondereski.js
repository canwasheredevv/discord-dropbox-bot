const { SlashCommandBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const { Dropbox } = require('dropbox');
const fetch = require('node-fetch');
const axios = require('axios');
const config = require('../config.js');

const dbx = new Dropbox({
    accessToken: config.dropbox.accessToken,
    fetch
});

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-gonder')
        .setDescription('Başka bir kullanıcıya bot içi mail gönderir (isteğe bağlı dosya ekli).')
        .addStringOption(o =>
            o.setName('alici')
             .setDescription('Alıcının mail adresi (ör: isim@dropbox.bot)')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('konu')
             .setDescription('Mail konusu')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('icerik')
             .setDescription('Mail içeriği')
             .setRequired(true)
        )
        .addAttachmentOption(o =>
            o.setName('dosya')
             .setDescription('Maile eklenecek dosya (isteğe bağlı)')
             .setRequired(false)
        ),

    async execute(interaction, db) {
        const gonderenId = interaction.user.id;
        const gonderen = await db.get(`user_${gonderenId}`);
        if (!gonderen) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        const aliciMail = interaction.options.getString('alici');
        const konu = interaction.options.getString('konu');
        const icerik = interaction.options.getString('icerik');
        const attachment = interaction.options.getAttachment('dosya') || null;

        const aliciId = await db.get(`mail_${aliciMail}`);
        if (!aliciId) {
            return interaction.reply({
                content: "Bu mail adresiyle kayıtlı bir kullanıcı bulunamadı.",
                flags: 64
            });
        }

        if (aliciId === gonderenId) {
            return interaction.reply({
                content: "Kendine mail göndermek için gerek yok, not defteri kullan :)",
                flags: 64
            });
        }

        const alici = await db.get(`user_${aliciId}`);
        if (!alici) {
            return interaction.reply({
                content: "Alıcının kullanıcı verisi bulunamadı.",
                flags: 64
            });
        }

        // ENGEL KONTROLLERİ
        gonderen.engellediklerim = gonderen.engellediklerim || [];
        alici.engellediklerim = alici.engellediklerim || [];

        if (gonderen.engellediklerim.includes(aliciId)) {
            return interaction.reply({
                content: "Engellediğin bir kullanıcıya mail gönderemezsin.",
                flags: 64
            });
        }

        if (alici.engellediklerim.includes(gonderenId)) {
            return interaction.reply({
                content: "Bu kullanıcı seni engellemiş, ona mail gönderemezsin.",
                flags: 64
            });
        }

        await interaction.deferReply({ flags: 64 });

        let dosyaBilgi = null;

        // DOSYA VARSA → DROPBOX'A YÜKLE
        if (attachment) {
            try {
                const res = await axios.get(attachment.url, { responseType: 'arraybuffer' });
                const buffer = Buffer.from(res.data);

                const dropboxPath = `/mail_ekleri/${gonderenId}/${Date.now()}_${attachment.name}`;

                await dbx.filesUpload({
                    path: dropboxPath,
                    contents: buffer,
                    mode: 'add',
                    autorename: true,
                    mute: false
                });

                // Paylaşılabilir link al
                let sharedLink;
                try {
                    const sharedRes = await dbx.sharingCreateSharedLinkWithSettings({ path: dropboxPath });
                    sharedLink = sharedRes.result.url;
                } catch (err) {
                    if (err?.error?.error?.['.tag'] === 'shared_link_already_exists') {
                        const existing = await dbx.sharingListSharedLinks({ path: dropboxPath, direct_only: true });
                        if (existing.result.links.length > 0) {
                            sharedLink = existing.result.links[0].url;
                        }
                    } else {
                        throw err;
                    }
                }

                const finalUrl = (sharedLink || '').replace('?dl=0', '?dl=1');

                dosyaBilgi = {
                    ad: attachment.name,
                    boyut: (attachment.size / 1024).toFixed(2) + " KB",
                    dropboxPath,
                    url: finalUrl
                };
            } catch (e) {
                console.error('Mail ek dosya yükleme hatası:', e);
                // Dosya yüklemesi patlarsa, mail yine de teksiz gönderilsin
            }
        }

        const mailId = uuidv4().split('-')[0];

        const mailObj = {
            id: mailId,
            gonderenId,
            gonderenMail: gonderen.mail,
            aliciId,
            aliciMail,
            konu,
            icerik,
            tarih: Date.now(),
            okundu: false,
            ek: dosyaBilgi // null veya obje
        };

        gonderen.gidenKutusu = gonderen.gidenKutusu || [];
        alici.gelenKutusu = alici.gelenKutusu || [];

        gonderen.gidenKutusu.push(mailObj);
        alici.gelenKutusu.push(mailObj);

        await db.set(`user_${gonderenId}`, gonderen);
        await db.set(`user_${aliciId}`, alici);

        // Alıcıya DM
        try {
            const user = await interaction.client.users.fetch(aliciId);
            let text =
                `📩 Yeni bir bot içi mail aldın!\n` +
                `**Gönderen:** ${gonderen.mail}\n` +
                `**Konu:** ${konu}\n` +
                `**Mail ID:** \`${mailId}\``;

            if (dosyaBilgi && dosyaBilgi.url) {
                text += `\n**Ek:** \`${dosyaBilgi.ad}\` (${dosyaBilgi.boyut})`;
            }

            user.send(text).catch(() => null);
        } catch {}

        let replyText =
            `📨 Mailin gönderildi!\n` +
            `**Alıcı:** \`${aliciMail}\`\n` +
            `**Mail ID:** \`${mailId}\``;

        if (dosyaBilgi && dosyaBilgi.url) {
            replyText += `\n**Eklenen Dosya:** \`${dosyaBilgi.ad}\` (${dosyaBilgi.boyut})`;
        }

        return interaction.editReply({ content: replyText });
    }
};