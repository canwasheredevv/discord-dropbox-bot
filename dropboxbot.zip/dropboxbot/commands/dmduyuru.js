const { SlashCommandBuilder } = require('discord.js');
const config = require('../config.js');
module.exports = {
    data: new SlashCommandBuilder().setName('dmduyuru').setDescription('Bot kullanıcılarına duyuru gönderir.').addStringOption(o => o.setName('mesaj').setRequired(true).setDescription('Duyuru metni')),
    async execute(interaction, db) {
        if (interaction.user.id !== config.sahipID) return interaction.reply("Yetkiniz yok.");
        const users = await db.all();
        users.filter(u => u.id.startsWith('user_')).forEach(async u => {
            const discordUser = await interaction.client.users.fetch(u.id.split('_')[1]).catch(() => null);
            if (discordUser) discordUser.send(`📢 **Duyuru:** ${interaction.options.getString('mesaj')}`);
        });
        await interaction.reply("✅ Duyuru gönderiliyor...");
    }
};
