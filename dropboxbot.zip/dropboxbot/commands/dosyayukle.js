const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');
const { Dropbox } = require('dropbox');
const fetch = require('node-fetch');
const config = require('../config.js');

const dbx = new Dropbox({
    accessToken: config.dropbox.accessToken,
    fetch
});

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('dosya-yukle')
        .setDescription('Dropbox sürücüne 3 saatlik süreli dosya yükler.')
        .addAttachmentOption(opt =>
            opt.setName('dosya')
               .setDescription('Yüklenecek dosya')
               .setRequired(true)
        ),

    async execute(interaction, db) {
        const userData = await db.get(`user_${interaction.user.id}`);
        if (!userData) {
            return interaction.reply({ content: "Önce `/hesap-olustur` ile kayıt olmalısın!", flags: 64 });
        }

        if (userData.hak <= 0) {
            return interaction.reply({ content: "Yükleme hakkın kalmamış. `/gunluk-hak` komutunu kullanabilirsin.", flags: 64 });
        }

        await interaction.deferReply({ flags: 64 }); // ephemeral

        try {
            const attachment = interaction.options.getAttachment('dosya');

            // Discord attachment'ı buffer olarak çek
            const res = await axios.get(attachment.url, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(res.data);

            // Dropbox path (kullanıcıya özel klasör)
            const dropboxPath = `/googledrivebot/${interaction.user.id}/${Date.now()}_${attachment.name}`;

            // 1) Dropbox'a yükle
            await dbx.filesUpload({
                path: dropboxPath,
                contents: buffer,
                mode: 'add',
                autorename: true,
                mute: false
            });

            // 2) Paylaşılabilir link oluştur / varsa getir
            let sharedLink;
            try {
                const sharedRes = await dbx.sharingCreateSharedLinkWithSettings({ path: dropboxPath });
                sharedLink = sharedRes.result.url;
            } catch (err) {
                if (err?.error?.error?.['.tag'] === 'shared_link_already_exists') {
                    const existing = await dbx.sharingListSharedLinks({ path: dropboxPath, direct_only: true });
                    if (existing.result.links.length > 0) {
                        sharedLink = existing.result.links[0].url;
                    }
                } else {
                    throw err;
                }
            }

            if (!sharedLink) {
                throw new Error('Paylaşılabilir link alınamadı.');
            }

            // Linki direkt indirme moduna çevir (dl=1)
            const finalUrl = sharedLink.replace('?dl=0', '?dl=1');

            // Kod ve 3 saatlik süre
            const kod = Math.random().toString(36).substring(2, 8).toUpperCase();
            const silinmeZamani = Date.now() + (3 * 60 * 60 * 1000);

            const dosyaBilgi = {
                id: kod,
                // dropboxPath istersen ileride silme için tutarsın
                dropboxPath,
                ad: attachment.name,
                url: finalUrl,
                boyut: (attachment.size / 1024).toFixed(2) + " KB",
                silinmeTarihi: silinmeZamani
            };

            await db.push(`user_${interaction.user.id}.dosyalar`, dosyaBilgi);
            await db.sub(`user_${interaction.user.id}.hak`, 1);

            await interaction.editReply(
                `✅ **Yüklendi! (DropBox doğrudan dosya üretmez, sadece dosya depolar!)**\n` +
                `• Kod: \`${kod}\`\n` +
                `• Link: ${finalUrl}\n` +
                `⏰ Bu dosya **3 saat sonra** otomatik olarak silinecektir.`
            );
        } catch (error) {
            console.error(error);
            await interaction.editReply("❌ Dropbox'a yüklenirken bir hata oluştu.");
        }
    }
};