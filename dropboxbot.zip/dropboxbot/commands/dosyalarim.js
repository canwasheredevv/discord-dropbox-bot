const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.js');

module.exports = {
    data: new SlashCommandBuilder().setName('dosyalarim').setDescription('Dosyalarını listeler.'),
    async execute(interaction, db) {
        const data = await db.get(`user_${interaction.user.id}`);
        if (!data || !data.dosyalar.length) return interaction.reply("Dosya bulunamadı.");
        const liste = data.dosyalar.map((d, i) => `**${i+1}.** \`${d.id}\` - ${d.ad}`).join('\n');
        const embed = new EmbedBuilder().setTitle("Dosyalarım").setDescription(liste).setColor(config.embedRenk);
        await interaction.reply({ embeds: [embed] });
    }
};
