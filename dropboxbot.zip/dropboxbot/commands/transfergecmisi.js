const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('transfer-gecmisi')
        .setDescription('Gönderdiğiniz son dosyaların listesini gösterir.'),
    async execute(interaction, db) {
        const data = await db.get(`user_${interaction.user.id}`);
        if (!data || !data.gecmis || data.gecmis.length === 0) {
            return interaction.reply({ content: "Henüz kimseye dosya göndermemişsin.", ephemeral: true });
        }

        const liste = data.gecmis.slice(-10).map((t, i) => 
            `**${i+1}.** \`${t.tarih}\` - **${t.alici}** kişisine \`${t.dosyaAd}\` gönderildi.`
        ).join('\n');

        const embed = new EmbedBuilder()
            .setTitle("📤 Dosya Transfer Geçmişi")
            .setDescription(liste)
            .setColor("#34a853")
            .setFooter({ text: "Son 10 işlem gösteriliyor." });

        await interaction.reply({ embeds: [embed] });
    }
};
