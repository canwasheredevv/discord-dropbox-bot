const { SlashCommandBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('mail-gonder')
        .setDescription('Başka bir kullanıcıya bot içi mail gönderir.')
        .addStringOption(o =>
            o.setName('alici')
             .setDescription('Alıcının mail adresi (örn: isim@googledrive.bot)')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('konu')
             .setDescription('Mail konusu')
             .setRequired(true)
        )
        .addStringOption(o =>
            o.setName('icerik')
             .setDescription('Mail içeriği')
             .setRequired(true)
        ),

    async execute(interaction, db) {
        const gonderenId = interaction.user.id;
        const gonderen = await db.get(`user_${gonderenId}`);
        if (!gonderen) {
            return interaction.reply({ content: "Önce `/hesap-olustur` ile kayıt olmalısın!", flags: 64 });
        }

        const aliciMail = interaction.options.getString('alici');
        const konu = interaction.options.getString('konu');
        const icerik = interaction.options.getString('icerik');

        const aliciId = await db.get(`mail_${aliciMail}`);
        if (!aliciId) {
            return interaction.reply({ content: "Bu mail adresiyle kayıtlı bir kullanıcı yok.", flags: 64 });
        }

        const alici = await db.get(`user_${aliciId}`);
        if (!alici) {
            return interaction.reply({ content: "Alıcının kullanıcı verisi bulunamadı.", flags: 64 });
        }

        const mailId = uuidv4().split('-')[0];

        const mailObj = {
            id: mailId,
            gonderenId,
            gonderenMail: gonderen.mail,
            aliciId,
            aliciMail,
            konu,
            icerik,
            tarih: Date.now(),
            okundu: false
        };

        gonderen.gidenKutusu = gonderen.gidenKutusu || [];
        alici.gelenKutusu = alici.gelenKutusu || [];

        gonderen.gidenKutusu.push(mailObj);
        alici.gelenKutusu.push(mailObj);

        await db.set(`user_${gonderenId}`, gonderen);
        await db.set(`user_${aliciId}`, alici);

        try {
            const user = await interaction.client.users.fetch(aliciId);
            user.send(`📩 Yeni bir bot içi mail aldın!\n**Gönderen:** ${gonderen.mail}\n**Konu:** ${konu}\nMail ID: \`${mailId}\``)
                .catch(() => null);
        } catch {}

        return interaction.reply({
            content: `📨 Mail gönderildi!\n**Alıcı:** \`${aliciMail}\`\n**Mail ID:** \`${mailId}\``,
            flags: 64
        });
    }
};