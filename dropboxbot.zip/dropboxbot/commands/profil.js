const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('profil')
        .setDescription('Profilinizi, dosya istatistiklerinizi ve gizlilik ayarlarınızı gösterir.'),

    async execute(interaction, db) {
        const u = await db.get(`user_${interaction.user.id}`);
        if (!u) {
            return interaction.reply({
                content: "Önce `/hesap-olustur` ile kayıt olmalısın!",
                flags: 64
            });
        }

        // Mail kutuları yoksa oluştur
        u.gelenKutusu = u.gelenKutusu || [];
        u.gidenKutusu = u.gidenKutusu || [];

        const gelenSayisi = u.gelenKutusu.length;
        const gidenSayisi = u.gidenKutusu.length;
        const okunmamis = u.gelenKutusu.filter(m => !m.okundu).length;

        const embed = new EmbedBuilder()
            .setTitle(`${u.isim} (@${interaction.user.username})`)
            .setThumbnail(interaction.user.displayAvatarURL())
            .setColor(config.embedRenk)
            .addFields(
                {
                    name: "📝 Biyografi",
                    value: u.bio || "Henüz bir biyografi yazılmamış.",
                    inline: false
                },
                {
                    name: "📧 Mail",
                    value: u.mailGizli
                        ? "||Gizli Adres||"
                        : `\`${u.mail}\`\nBu adres ile diğer kullanıcılar sana bot içi **mail** gönderebilir.`,
                    inline: false
                },
                {
                    name: "📬 Mail Kutusu",
                    value:
                        `• Gelen: **${gelenSayisi}**\n` +
                        `• Giden: **${gidenSayisi}**\n` +
                        `• Okunmamış: **${okunmamis}**`,
                    inline: true
                },
                {
                    name: "📅 Doğum Tarihi",
                    value: u.tarihGizli ? "||Gizli Tarih||" : `\`${u.dogumTarihi}\``,
                    inline: true
                },
                {
                    name: "🔑 Yükleme Hakkı",
                    value: `**${u.hak}**`,
                    inline: true
                },
                {
                    name: "📁 Dosya Sayısı",
                    value: `**${u.dosyalar.length}**`,
                    inline: true
                }
            )
            .setFooter({ text: "Ayarlar butonu sadece size özeldir." });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`ayarlar_${interaction.user.id}`)
                .setLabel('⚙️ Profil Ayarları')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId(`mail_kisayol_${interaction.user.id}`)
                .setLabel('📥 Mail Kutum')
                .setStyle(ButtonStyle.Primary)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};