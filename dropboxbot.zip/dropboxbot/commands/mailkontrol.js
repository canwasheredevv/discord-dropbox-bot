const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mail-sorgula')
        .setDescription('Bir mail adresinin hangi kullanıcıya ait olduğunu gösterir.') // Komut açıklaması
        .addStringOption(option => 
            option.setName('mail')
                .setDescription('Sorgulanacak mail adresini girin (Örn: can@dropbox.bot)') // Seçenek açıklaması (HATA BURADAYDI)
                .setRequired(true)
        ),
    async execute(interaction, db) {
        const mailAdresi = interaction.options.getString('mail').toLowerCase();
        const userId = await db.get(`mail_${mailAdresi}`);

        if (!userId) {
            return interaction.reply({ content: "❌ Bu mail adresine sahip bir kullanıcı bulunamadı.", ephemeral: true });
        }

        const userData = await db.get(`user_${userId}`);
        
        await interaction.reply({ 
            content: `🔍 **Sorgu Sonucu:**\n📧 \`${mailAdresi}\` adresi **${userData.isim}** kullanıcısına aittir.`, 
            ephemeral: true 
        });
    },
};
