const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');
const os = require('os');
const config = require('../config.js');

module.exports = {
    integration_types: [0, 1],
    contexts: [0, 1, 2],

    data: new SlashCommandBuilder()
        .setName('istatistik')
        .setDescription('Botun sistem, kullanım ve genel istatistiklerini gösterir.'),

    /**
     * @param {import('discord.js').ChatInputCommandInteraction} interaction
     * @param {*} db   
     */
    async execute(interaction, db) {
        // ❌ SORUN 1: DB.all() ve döngü 3 saniyeden fazla sürerse Discord timeout atar
        // ✅ ÇÖZÜM: Önce deferReply ile Discord'u beklet
        await interaction.deferReply();

        const client = interaction.client;

        // Tüm verileri hesapla (bu işlem yavaş olabilir)
        const stats = await computeStats(client, db);

        const pages = createPages(stats, client, interaction.user, config);

        let currentPage = 0;

        const row = createRow(pages, currentPage);

        // ✅ Orijinal reply yerine editReply kullan
        const msg = await interaction.editReply({
            embeds: [pages[currentPage]],
            components: [row]
        });

        // Collector
        const collector = msg.createMessageComponentCollector({
            time: 1000 * 60 * 2 // 2 dakika
        });

        collector.on('collect', async (btn) => {
            if (btn.user.id !== interaction.user.id) {
                return btn.reply({ 
                    content: 'Bu istatistik sayfasını sadece komutu kullanan kişi kontrol edebilir.', 
                    ephemeral: true 
                });
            }

            // ✅ SORUN 2: refresh'te reply + update yapılıyordu (çift response hatası)
            // ✅ ÇÖZÜM: deferUpdate ile güvenli update
            await btn.deferUpdate();

            const customId = btn.customId;

            if (customId === 'istatistik_prev') {
                if (currentPage > 0) currentPage--;
            } else if (customId === 'istatistik_next') {
                if (currentPage < pages.length - 1) currentPage++;
            } else if (customId === 'istatistik_refresh') {
                // ✅ Gerçek refresh: Yeniden hesapla
                const newStats = await computeStats(client, db);
                const newPages = createPages(newStats, client, interaction.user, config);
                pages.splice(0, pages.length, ...newPages); // pages'i güncelle
                currentPage = Math.min(currentPage, pages.length - 1);
            }

            const newRow = createRow(pages, currentPage);

            // ✅ Tek response: update
            await btn.editReply({
                embeds: [pages[currentPage]],
                components: [newRow]
            });
        });

        collector.on('end', async () => {
            // ✅ Hata yut (zaten disable edilebilir)
            try {
                const disabledRow = createDisabledRow();
                await msg.edit({ components: [disabledRow] });
            } catch {}
        });
    }
};

// ✅ Yardımcı fonksiyonlar: Kodu temizlemek için dışarı çıkardık
async function computeStats(client, db) {
    const uptimeMs = client.uptime || 0;
    const uptimeSec = Math.floor(uptimeMs / 1000);
    const days = Math.floor(uptimeSec / 86400);
    const hours = Math.floor((uptimeSec % 86400) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const seconds = uptimeSec % 60;

    const memoryUsage = process.memoryUsage();
    const heapUsedMB = (memoryUsage.heapUsed / 1024 / 1024).toFixed(2);
    const rssMB = (memoryUsage.rss / 1024 / 1024).toFixed(2);

    const totalMemGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const freeMemGB = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);

    const cpuModel = os.cpus()[0]?.model || 'Bilinmiyor';
    const cpuCores = os.cpus().length;

    const guildCount = client.guilds.cache.size;
    const userCount = client.users.cache.size;
    const channelCount = client.channels.cache.size;
    const wsPing = client.ws.ping;

    let totalUsers = 0;
    let totalFiles = 0;
    let totalTransfers = 0;
    let totalUploadQuota = 0;

    try {
        const allKeys = await db.all();
        const userKeys = allKeys.filter(k => k.id?.startsWith?.('user_'));

        totalUsers = userKeys.length;

        for (const entry of userKeys) {
            const u = entry.value;
            if (!u) continue;

            if (Array.isArray(u.dosyalar)) {
                totalFiles += u.dosyalar.length;
            }
            if (typeof u.gonderimSayisi === 'number') {
                totalTransfers += u.gonderimSayisi;
            }
            if (typeof u.hak === 'number') {
                totalUploadQuota += u.hak;
            }
        }
    } catch (e) {
        console.error('İstatistik DB okuma hatası:', e);
    }

    return {
        uptime: { days, hours, minutes, seconds },
        memory: { heapUsedMB, rssMB, totalMemGB, freeMemGB },
        cpu: { model: cpuModel, cores: cpuCores },
        discord: { guildCount, userCount, channelCount, wsPing },
        db: { totalUsers, totalFiles, totalTransfers, totalUploadQuota }
    };
}

function createPages(stats, client, user, config) {
    const page1 = new EmbedBuilder()
        .setTitle('📊 DropBox İstatistikleri')
        .setColor(config.embedRenk || 0x34a853)
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
            {
                name: '🌐 Sunucu / Kullanıcı / Kanal',
                value: `• Sunucu: **${stats.discord.guildCount}**\n• Kullanıcı (cache): **${stats.discord.userCount}**\n• Kanal (cache): **${stats.discord.channelCount}**`,
                inline: false
            },
            {
                name: '⏱️ Çalışma Süresi',
                value: `\`${stats.uptime.days}g ${stats.uptime.hours}s ${stats.uptime.minutes}d ${stats.uptime.seconds}s\``,
                inline: true
            },
            {
                name: '📡 Gecikme',
                value: `• WS Ping: **${stats.discord.wsPing} ms**`,
                inline: true
            },
            {
                name: '👤 Kayıtlı Kullanıcılar (DB)',
                value: `• Toplam kullanıcı: **${stats.db.totalUsers}**`,
                inline: false
            },
            {
                name: '📁 Dosya ve Transferler (DB)',
                value: `• Toplam dosya: **${stats.db.totalFiles}**\n• Toplam transfer: **${stats.db.totalTransfers}**`,
                inline: false
            }
        )
        .setFooter({ text: `İsteyen: ${user.tag}`, iconURL: user.displayAvatarURL() })
        .setTimestamp();

    const page2 = new EmbedBuilder()
        .setTitle('🖥️ Sistem İstatistikleri')
        .setColor(config.embedRenk || 0x34a853)
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
            {
                name: '💾 Bellek Kullanımı (Process)',
                value: `• Heap Used: **${stats.memory.heapUsedMB} MB**\n• RSS: **${stats.memory.rssMB} MB**`,
                inline: true
            },
            {
                name: '🧠 Sistem RAM',
                value: `• Toplam: **Erişim Reddedildi**`, //${stats.memory.totalMemGB} GB**\n• Boş: **${stats.memory.freeMemGB} GB
                inline: true
            },
            {
                name: '⚙️ CPU',
                value: `• Model: **Erişim Reddedildi**`, // \`${stats.cpu.model}\`\n• Çekirdek: **${stats.cpu.cores}
                inline: false
            },
            {
                name: '🧾 Sürümler',
                value: `• Node.js: \`${process.version}\`\n• discord.js: \`${require('discord.js').version}\``,
                inline: false
            }
        )
        .setFooter({ text: `DropBox BOT • Sistem Durumu`, iconURL: client.user.displayAvatarURL() })
        .setTimestamp();

    const page3 = new EmbedBuilder()
        .setTitle('📈 Kullanım ve Kota İstatistikleri')
        .setColor(config.embedRenk || 0x34a853)
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
            {
                name: '🔑 Yükleme Hakları',
                value: `• Kullanıcı başına ortalama hak: **${stats.db.totalUsers ? (stats.db.totalUploadQuota / stats.db.totalUsers).toFixed(2) : 0}**\n• Toplam hak (tüm kullanıcılar): **${stats.db.totalUploadQuota}**`,
                inline: false
            },
            {
                name: '📥 Dosya Kullanımı',
                value: 'Özelleştirilebilir alan.',
                inline: false
            }
        )
        .setFooter({ text: 'Veriler anlık olarak güncellendi.', iconURL: user.displayAvatarURL() })
        .setTimestamp();

    return [page1, page2, page3];
}

function createRow(pages, currentPage) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('istatistik_prev')
            .setLabel('◀️ Geri')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === 0),

        new ButtonBuilder()
            .setCustomId('istatistik_refresh')
            .setLabel('🔄 Yenile')
            .setStyle(ButtonStyle.Primary),

        new ButtonBuilder()
            .setCustomId('istatistik_next')
            .setLabel('İleri ▶️')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === pages.length - 1)
    );
}

function createDisabledRow() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('istatistik_prev')
            .setLabel('◀️ Geri')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),

        new ButtonBuilder()
            .setCustomId('istatistik_refresh')
            .setLabel('🔄 Yenile')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(true),

        new ButtonBuilder()
            .setCustomId('istatistik_next')
            .setLabel('İleri ▶️')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true)
    );
}